# Guswan Motion

Editor motion graphics native Android untuk Android Studio. Versi 0.2.0, Android 8.0+.

## Unduh APK

[Unduh APK terbaru](https://github.com/guswanreal/guswanapp/raw/refs/heads/apk-download/guswan-motion-debug.apk)

Build debug untuk mencoba aplikasi. APK baru memakai package yang sama (`com.guswan.motion`) dan versionCode 2 sehingga bisa memperbarui versi 0.1 tanpa menghapus data, selama kunci debug penandatanganan sama. Cadangkan proyek lewat ekspor `.gwm` sebelum memperbarui.

## Workspace

- **Beranda:** banyak proyek lokal, preview dari komposisi asli, pencarian, salin, hapus, impor dan contoh opsional.
- **Editor:** teks, persegi, lingkaran, gambar dan video; timeline, trim, susunan layer, visibility/lock, transform, undo/redo dan autosave.
- **Graph & Flow:** graph nilai dan kecepatan, cubic Bézier dengan handle yang bisa ditarik dan slider presisi, preset Easy ease / Ease in / Ease out / Snap / Overshoot. Kurva mengatur segmen menuju keyframe akhir dan dipakai semua komponen transform layer. Flow adalah preset bawaan, bukan host plugin Adobe.
- **Time remap:** titik waktu komposisi/sumber, kurva halus atau linear, speed ramp, freeze dan reverse. Untuk video, remap mengubah frame sumber; transform tetap mengikuti waktu komposisi. Untuk layer lain, remap mengubah waktu pembacaan keyframe. Preview dan ekspor memakai remap yang sama.
- **Studio 3D:** kubus, bola, bidang, impor mesh OBJ, kamera orbit/pitch/distance/lens, shading arah sederhana, wireframe, posisi XY/Z dan rotasi XYZ yang bisa dianimasikan. Grid hanya panduan viewport. Ini renderer perspektif berbasis polygon; belum editor mesh Blender atau render engine dengan z-buffer/ray tracing.
- **Face tracking:** ML Kit face detector yang dibundel memproses layer video di HP, disampel setiap 200 ms (5 fps), memilih wajah terbesar di awal lalu mengikuti tracking ID. Hasil posisi, skala dan estimasi Euler XYZ dibake menjadi keyframe objek wireframe. Frame tanpa deteksi menyembunyikan objek. Tracking mengatur kamera ke tampak depan. Ulangi tracking setelah transform atau time remap sumber berubah.
- **Tampilan:** brightness, saturation dan blending Normal/Add/Multiply/Screen untuk layer 2D; shadow untuk teks/bentuk; warna dan brightness untuk mesh 3D.
- **Ekspor:** PNG resolusi komposisi; H.264 MP4 30 fps tanpa audio (960 px sisi panjang atau 720 px persegi); proyek `.gwm` dengan gambar, video, mesh, kamera, kurva dan keyframe.

## Batas saat ini

Komposisi 1–30 detik, maksimum 40 layer dan proyek 24 MB. Impor video maksimum 12 MB; gunakan klip pendek. Frame video diambil dari frame terdekat menggunakan decoder Android; tidak ada optical flow atau audio. Jaga aplikasi tetap terbuka saat ekspor atau tracking. Pekerjaan berhenti jika activity ditutup/dibuat ulang.

Proyek format v1 dari versi 0.1 dapat dibuka. Penyimpanan baru memakai format v2; gunakan versi aplikasi baru untuk membukanya.

Face tracking mengestimasi pose kepala dari gambar 2D. Belum ada rekonstruksi mesh wajah, depth terkalibrasi, live camera AR, camera solve scene 3D, atau jaminan identitas ketika wajah keluar lama dari frame. Kualitas bergantung pada wajah yang terlihat, pencahayaan dan gerakan. Inferensi menggunakan model lokal; SDK ML Kit juga menambahkan izin Internet/network-state untuk layanan SDK, sehingga build ini belum merupakan jaminan tidak ada lalu lintas jaringan SDK.

Fitur AE/Blender berikut belum tersedia: masking/roto/keying, audio mixing, expressions/scripting, precomp/parenting, motion blur, stabilization/particles, mesh editing/rigging/UV/material nodes, simulasi dan Cycles/Eevee. File `.aep`, plugin `.aex/.jsx`, dan proyek Alight Motion tidak didukung. Daftar yang sama tersedia di **Fitur & panduan** dalam aplikasi.

## Buka di Android Studio

1. Buka folder ini, gunakan JDK 17 dan Android SDK 35.
2. Biarkan Gradle sync selesai. Hubungkan HP dengan USB debugging atau pilih emulator.
3. Pilih konfigurasi `app`, kemudian Run. Preview Compose tersedia di `MainActivity.kt`.

## Build cloud

```bash
bash scripts/setup-cloud.sh
bash scripts/cloud-build.sh
bash scripts/cloud-build.sh :app:assembleDebugAndroidTest
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

Validasi: [docs/VALIDATION.md](docs/VALIDATION.md). Media uji: [docs/TEST-ASSETS.md](docs/TEST-ASSETS.md).
