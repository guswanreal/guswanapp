# Guswan Motion

Direction comes from the requested combination of After Effects and Alight Motion:
a precision timeline and compositing workspace adapted for a phone.

- Identity: a small, local-first motion graphics workshop. Product name is text;
  no invented logo or promotional imagery.
- Palette: charcoal #111315 and #1C2024 let the user's composition remain the
  focal point. Warm amber #FFBD69 marks selection, keyframes and primary actions.
- Typography: Android system sans respects device font scaling and keeps dense
  editing controls readable. Tabular time uses monospace only for alignment.
- Layout: preview above transport, timeline, and a contextual inspector. On a
  wide display, preview and transport sit beside a panel with Timeline/Properti
  tabs so a short landscape screen keeps a usable preview.
- Spacing: 8dp rhythm, 16dp panel padding, controls at least 48dp tall. Timeline
  marks are editing data, not decorative background texture.
- Large text: at font scale above 140%, tools become a two-column grid and time
  readouts sit above playback buttons. Resolution remains in project settings;
  the main metadata line prioritizes the save state to leave space for preview.
  Timeline opens in a sheet so the preview remains usable with large text.
- Shape: restrained 8dp corners on tools, straight timeline rails. No glass or
  decorative glow. A layer's shadow is an editable composition effect.
- Icons: Material editor symbols reflect familiar Android actions. A diamond
  represents an actual keyframe, never an AI feature.
- Motion: only playback and user-triggered state changes animate. The rest of
  the workspace stays still so editing remains precise.
- ENERGY 1 / RHYTHM 2 / MOTION 2. Preview is the focal point; panels have different
  proportions because transport, tracks and properties have different jobs.
- Content: projects start empty. The optional example is explicitly labeled
  "Contoh animasi" and is editable project data, not a fabricated user project.
- Scope: native Android motion graphics v0.1. No claim of full compatibility
  with AE/Alight project formats, audio/video tracks, or their complete effects.

## Extension 0.2

The user explicitly requested a home screen, Blender-like 3D studio, AE-style
graphs, Flow easing, time ramps and face tracking, while keeping the prior visual
direction. The charcoal/amber palette and ENERGY 1 / RHYTHM 2 / MOTION 2 remain.

- Home puts project creation first and actual locally saved projects beneath it.
  Thumbnails are renders of those projects, not invented portfolio examples.
- Four bottom actions stay readable: Add, Properties, Tools and Export. Advanced
  tools open full-screen workspaces with a back button and scrollable controls.
- Graph grids and the studio floor grid encode time/value and spatial reference;
  neither is background decoration. Time and numeric labels use monospace only
  where alignment matters. Graph handle gestures have equivalent labeled sliders.
- Studio primitives are editable scene data requested by the user, not decorative
  product illustration. New 3D scenes contain one cube, visibly named Kubus.
- Feature availability lives in a real guide, with explicit current/unsupported
  groups. No dead feature tiles, invented plugin claims or unlabeled mock tracking.
- Material icons denote their actual tools: cube/studio, face/tracking, chart/graph,
  folder/import, speed/remap. Mint is a composition object color for the tracked
  face, not an additional global UI accent.
