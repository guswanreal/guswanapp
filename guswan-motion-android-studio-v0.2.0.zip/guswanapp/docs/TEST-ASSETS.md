# Instrumentation media fixture

`app/src/androidTest/assets/face-motion.mp4` is a 1.2-second translation of the public-domain US Navy portrait of Rear Admiral Grace Hopper.

Source: https://raw.githubusercontent.com/matplotlib/matplotlib/main/lib/matplotlib/mpl-data/sample_data/grace_hopper.jpg

Matplotlib identifies this photograph as public domain in its sample-data documentation (US Navy image). The clip is used only by instrumentation tests, never bundled in the installed production app, and never presented as a user project or product imagery.

The test verifies that the real bundled ML Kit detector finds a moving face and produces position and Euler-angle keyframes. It does not establish accuracy on arbitrary videos, identities, lighting, occlusions or rapid motion.
