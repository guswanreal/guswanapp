# Preview pada HP dan emulator

## Android Studio di komputer

1. Ekstrak ZIP proyek, lalu buka folder yang memuat `settings.gradle.kts`.
2. Pilih JDK 17 di Settings > Build Tools > Gradle.
3. Tunggu Gradle Sync dan instal SDK 35 jika diminta.
4. Hubungkan HP dengan USB, aktifkan Developer options > USB debugging, lalu
   setujui koneksi komputer pada HP.
5. Pilih HP di device selector dan jalankan konfigurasi `app`.

Gunakan Build > Build APK(s) untuk membuat APK sendiri. APK debug dari environment
ini juga bisa dipasang langsung pada HP Android 8.0 ke atas.

Untuk preview di IDE tanpa HP, buka `PhonePreview` pada `MainActivity.kt`, lalu
gunakan panel Compose Preview. Preview tersebut memuat contoh proyek yang sama
dengan renderer editor. **Interactive mode** pada Compose Preview dapat dipakai
untuk kontrol preview yang didukung versi Android Studio Anda. Jalankan app di
emulator atau HP untuk menguji file picker dan ekspor video.

## Environment cloud ini

Skill yang relevan adalah `android-cli`: SDK, emulator, deploy APK, inspeksi layout,
dan screenshot. Skill tidak menyediakan streaming HP melalui browser chat.

Toolchain yang disiapkan:

- `/workspace/toolchains/jdk-17.0.20+8`
- `/workspace/toolchains/android-sdk`
- `/workspace/toolchains/android-user/avd/GuswanPhone.avd`
- `scripts/cloud-build.sh` dan `scripts/setup-cloud.sh`

Environment tidak memiliki `/dev/kvm`. Emulator Android 30 dijalankan dalam mode
software; boot pertama memerlukan sekitar 6 menit 42 detik pada pengujian ini.
System UI sempat mengalami ANR dan Gradle sempat gagal membaca properti perangkat
dengan batas waktu default dua detik. Nilai `ddmlib.getprop.timeout.sec=60`
ditambahkan ke konfigurasi Gradle lokal untuk mengakomodasi respons emulator.
Hasil pengujian perangkat ada di `VALIDATION.md`; jangan menganggap hambatan
emulator sebagai hasil pengujian aplikasi yang lulus.

Proses emulator tidak ikut tersimpan sebagai proses hidup ketika environment
dipublikasikan. Jalankan lagi emulator setelah environment dipulihkan jika perlu.

Untuk menjalankan app pada emulator yang sudah hidup:

```sh
export ANDROID_USER_HOME=/workspace/toolchains/android-user
export PATH="/workspace/toolchains/android-sdk/platform-tools:$PATH"
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
adb shell am start -n com.guswan.motion/.MainActivity
```

Untuk screenshot dan struktur UI melalui Android CLI:

```sh
/workspace/toolchains/bin/android --sdk=/workspace/toolchains/android-sdk screen capture -o /tmp/guswan-screen.png
/workspace/toolchains/bin/android --sdk=/workspace/toolchains/android-sdk layout --flat --full
```

Rotasi viewport emulator dapat diatur lewat `adb shell wm set-user-rotation lock 1`
untuk landscape dan `adb shell wm set-user-rotation lock 0` untuk portrait.
Tunggu frame baru selesai dirender sebelum mengambil screenshot. Screenshot
hasil pengujian disediakan terpisah dari ZIP sumber.

HP pribadi belum tersambung ke environment cloud ini. Preview langsung di HP
dilakukan dari Android Studio pada komputer yang terhubung ke HP tersebut.
