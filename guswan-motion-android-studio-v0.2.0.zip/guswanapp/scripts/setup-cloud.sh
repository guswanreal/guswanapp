#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export GUSWAN_TOOLS_DIR="${GUSWAN_TOOLS_DIR:-/workspace/toolchains}"

python3 - <<'PY'
import hashlib
import os
import tarfile
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

tools = Path(os.environ['GUSWAN_TOOLS_DIR'])
downloads = tools / 'downloads'
downloads.mkdir(parents=True, exist_ok=True)

def fetch(url, filename, expected):
    target = downloads / filename
    if not target.exists():
        temp = target.with_suffix(target.suffix + '.part')
        with urllib.request.urlopen(url, timeout=120) as response, temp.open('wb') as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
        temp.rename(target)
    with target.open('rb') as source:
        actual = hashlib.file_digest(source, 'sha256').hexdigest()
    if actual != expected:
        raise SystemExit('Checksum mismatch; refusing to use ' + str(target))
    return target

if not (tools / 'jdk-17.0.20+8/bin/javac').exists():
    archive = fetch(
        'https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.20%2B8/'
        'OpenJDK17U-jdk_x64_linux_hotspot_17.0.20_8.tar.gz',
        'jdk17.tar.gz', 'be7668bc030d578b83d6d5ef9221d6d6729bbbca8cf94a7d52e16ac68b5a5a35')
    with tarfile.open(archive) as source:
        source.extractall(tools, filter='data')

sdk = tools / 'android-sdk'
if not (sdk / 'cmdline-tools/latest/bin/android').exists():
    archive = fetch('https://dl.google.com/android/repository/commandlinetools-linux-16111833_latest.zip',
        'android-commandlinetools.zip', '0877a1d048fe4a24efe2eff536ca4223f7adeb58648bb81909d33c446918cfa8')
    with zipfile.ZipFile(archive) as source:
        for info in source.infolist():
            if not info.filename.startswith('cmdline-tools/'):
                continue
            info.filename = 'latest/' + info.filename[len('cmdline-tools/'):]
            target = Path(source.extract(info, sdk / 'cmdline-tools'))
            if target.is_file():
                target.chmod((info.external_attr >> 16) & 0o777 or 0o644)

cache = tools / 'gradle-cache'
cache.mkdir(parents=True, exist_ok=True)
properties = cache / 'gradle.properties'
existing = properties.read_text() if properties.exists() else ''
updates = {'systemProp.ddmlib.getprop.timeout.sec': '60'}
proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
if proxy:
    address = urllib.parse.urlsplit(proxy)
    for scheme in ('http', 'https'):
        updates[f'systemProp.{scheme}.proxyHost'] = address.hostname
        updates[f'systemProp.{scheme}.proxyPort'] = str(address.port or 80)
trust = Path('/etc/ssl/certs/java/cacerts')
if trust.exists():
    updates['systemProp.javax.net.ssl.trustStore'] = str(trust)
with properties.open('a') as output:
    for key, value in updates.items():
        if value is not None and not any(line.startswith(key + '=') for line in existing.splitlines()):
            output.write(f'\n{key}={value}\n')
local = Path('local.properties')
if not local.exists():
    local.write_text('sdk.dir=' + str(sdk) + '\n')
print('JDK, SDK tools, proxy and trust configuration prepared.')
PY

export JAVA_HOME="$GUSWAN_TOOLS_DIR/jdk-17.0.20+8"
export ANDROID_HOME="$GUSWAN_TOOLS_DIR/android-sdk"
export ANDROID_USER_HOME="$GUSWAN_TOOLS_DIR/android-user"
export GRADLE_USER_HOME="$GUSWAN_TOOLS_DIR/gradle-cache"
mkdir -p "$ANDROID_USER_HOME"
android_cli="$ANDROID_HOME/cmdline-tools/latest/bin/android"
for package in platforms/android-35 build-tools/35.0.0 platform-tools; do
    if [[ ! -f "$ANDROID_HOME/$package/package.xml" ]]; then
        "$android_cli" --sdk="$ANDROID_HOME" sdk install "$package"
    fi
done
./scripts/cloud-build.sh
