#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

tools_dir="${GUSWAN_TOOLS_DIR:-/workspace/toolchains}"
export JAVA_HOME="${JAVA_HOME:-$tools_dir/jdk-17.0.20+8}"
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$tools_dir/gradle-cache}"
export ANDROID_USER_HOME="${ANDROID_USER_HOME:-$tools_dir/android-user}"
export ANDROID_HOME="${ANDROID_HOME:-$tools_dir/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/platform-tools:$tools_dir/bin:$PATH"

if [[ ! -x "$JAVA_HOME/bin/javac" ]]; then
    echo "JDK tidak ditemukan. Set JAVA_HOME ke JDK 17." >&2
    exit 1
fi
if [[ $# == 0 ]]; then
    set -- :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
fi
exec ./gradlew "$@" --console=plain
