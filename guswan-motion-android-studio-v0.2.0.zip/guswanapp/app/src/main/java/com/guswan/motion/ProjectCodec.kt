package com.guswan.motion

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object ProjectCodec {
    private fun number(o: JSONObject, key: String, fallback: Double, range: ClosedFloatingPointRange<Float>): Float =
        o.optDouble(key, fallback).toFloat().also { require(it.isFinite() && it in range) { "Nilai $key tidak valid." } }
    private fun pose(p: Pose) = JSONObject().put("x", p.x).put("y", p.y).put("scale", p.scale)
        .put("rotation", p.rotation).put("opacity", p.opacity).put("z", p.z).put("rotationX", p.rotationX).put("rotationY", p.rotationY)
    private fun readPose(o: JSONObject) = Pose(number(o,"x",.5,-2f..3f), number(o,"y",.5,-2f..3f),
        number(o,"scale",1.0,.01f..10f), number(o,"rotation",0.0,-3600f..3600f), number(o,"opacity",1.0,0f..1f),
        number(o,"z",0.0,-10f..10f), number(o,"rotationX",0.0,-3600f..3600f), number(o,"rotationY",0.0,-3600f..3600f))
    private fun curve(c: BezierCurve) = JSONArray(listOf(c.x1,c.y1,c.x2,c.y2))
    private fun readCurve(a: JSONArray?) = a?.let {
        require(it.length() == 4)
        BezierCurve(it.getDouble(0).toFloat(),it.getDouble(1).toFloat(),it.getDouble(2).toFloat(),it.getDouble(3).toFloat())
    } ?: BezierCurve()
    fun encode(p: MotionProject): String = JSONObject().apply {
        put("format","guswan-motion"); put("version",2); put("id",p.id); put("name",p.name)
        put("width",p.width); put("height",p.height); put("durationMs",p.durationMs); put("background",p.background)
        put("camera",JSONObject().put("yaw",p.camera.yaw).put("pitch",p.camera.pitch).put("distance",p.camera.distance).put("focal",p.camera.focal))
        put("layers",JSONArray().apply { p.layers.forEach { l -> put(JSONObject().apply {
            put("id",l.id); put("kind",l.kind.name); put("name",l.name); put("text",l.text); put("color",l.color)
            put("visible",l.visible); put("locked",l.locked); put("startMs",l.startMs); put("endMs",l.endMs)
            put("pose",pose(l.pose)); put("shadow",l.shadow); l.image?.let { put("image",it) }; l.video?.let { put("video",it) }
            put("sourceDurationMs",l.sourceDurationMs); put("mediaWidth",l.mediaWidth); put("mediaHeight",l.mediaHeight)
            put("wireframe",l.wireframe); put("brightness",l.brightness); put("saturation",l.saturation); put("blend",l.blend.name)
            put("keys",JSONArray().apply { l.keys.forEach { k -> put(JSONObject().put("timeMs",k.timeMs)
                .put("pose",pose(k.pose)).put("easing",k.easing.name).put("curve",curve(k.curve))) } })
            put("timeRemap",JSONArray().apply { l.timeRemap.forEach { t -> put(JSONObject().put("timeMs",t.timeMs)
                .put("sourceMs",t.sourceMs).apply { t.curve?.let { put("curve",curve(it)) } }) } })
            l.mesh?.let { mesh -> put("mesh",JSONObject().put("vertices",JSONArray().apply {
                mesh.vertices.forEach { put(JSONArray(listOf(it.x,it.y,it.z))) }
            }).put("faces",JSONArray().apply { mesh.faces.forEach { put(JSONArray(it)) } })) }
        }) } })
    }.toString()
    fun decode(text: String): MotionProject {
        require(text.length <= 24_000_000) { "File proyek terlalu besar (maksimum 24 MB)." }
        val o = JSONObject(text)
        require(o.getString("format") == "guswan-motion" && o.getInt("version") in 1..2) { "Format proyek belum didukung." }
        val duration = o.getInt("durationMs").also { require(it in 1000..30000) }
        val w = o.getInt("width").also { require(it in 64..3840) }; val h = o.getInt("height").also { require(it in 64..3840) }
        val a = o.getJSONArray("layers").also { require(it.length() <= 40) }
        val layers = (0 until a.length()).map { i ->
            val l = a.getJSONObject(i)
            val start = l.getInt("startMs").also { require(it in 0 until duration) }
            val end = l.getInt("endMs").also { require(it in start + 1..duration) }
            val sourceDuration = l.optInt("sourceDurationMs",6000).also { require(it in 1..3_600_000) }
            val keys = l.getJSONArray("keys").also { require(it.length() <= 1000) }
            val times = l.optJSONArray("timeRemap") ?: JSONArray()
            require(times.length() <= 1000)
            val timeRemap = (0 until times.length()).map { j -> val t = times.getJSONObject(j)
                TimePoint(t.getInt("timeMs").also { require(it in 0..duration) },
                    t.getInt("sourceMs").also { require(it in 0..3_600_000) }, if(t.has("curve")) readCurve(t.getJSONArray("curve")) else null)
            }.sortedBy { it.timeMs }.also { require(it.map { t -> t.timeMs }.distinct().size == it.size) }
            val mesh = l.optJSONObject("mesh")?.let { m ->
                val v = m.getJSONArray("vertices").also { require(it.length() in 1..2000) }
                val f = m.getJSONArray("faces").also { require(it.length() in 1..4000) }
                MeshData((0 until v.length()).map { j -> val p = v.getJSONArray(j)
                    val n = (0..2).map { p.getDouble(it).toFloat().also { n -> require(n.isFinite() && n in -100f..100f) } }
                    Vec3(n[0],n[1],n[2]) }, (0 until f.length()).map { j -> val face = f.getJSONArray(j)
                    require(face.length() in 3..64)
                    (0 until face.length()).map { face.getInt(it).also { n -> require(n in 0 until v.length()) } } })
            }
            MotionLayer(id=l.getString("id"),kind=LayerKind.valueOf(l.getString("kind")),name=l.getString("name").take(80),
                text=l.getString("text").take(300),color=l.getInt("color"),visible=l.getBoolean("visible"),locked=l.getBoolean("locked"),
                startMs=start,endMs=end,pose=readPose(l.getJSONObject("pose")),shadow=number(l,"shadow",0.0,0f..60f),
                image=if(l.has("image")) l.getString("image") else null, video=if(l.has("video")) l.getString("video") else null,
                sourceDurationMs=sourceDuration,mediaWidth=l.optInt("mediaWidth",1080).also { require(it in 1..16384) },
                mediaHeight=l.optInt("mediaHeight",1920).also { require(it in 1..16384) },timeRemap=timeRemap,mesh=mesh,
                wireframe=l.optBoolean("wireframe",false),brightness=number(l,"brightness",0.0,-1f..1f),
                saturation=number(l,"saturation",1.0,0f..2f),blend=BlendMode.valueOf(l.optString("blend","NORMAL")),
                keys=(0 until keys.length()).map { j -> val k = keys.getJSONObject(j)
                    Keyframe(k.getInt("timeMs").also { require(it in 0..30000) },readPose(k.getJSONObject("pose")),
                        Easing.valueOf(k.getString("easing")),readCurve(k.optJSONArray("curve")))
                }.also { require(it.map { k -> k.timeMs }.distinct().size == it.size) }.sortedBy { it.timeMs })
        }
        require(layers.map { it.id }.distinct().size == layers.size)
        val c = o.optJSONObject("camera") ?: JSONObject()
        return MotionProject(o.getString("name").take(80),w,h,duration,o.getInt("background"),layers,
            o.optString("id",UUID.randomUUID().toString()).also { require(it.matches(Regex("[A-Za-z0-9-]{1,80}"))) },
            Camera3D(number(c,"yaw",-22.0,-180f..180f),number(c,"pitch",15.0,-85f..85f),
                number(c,"distance",5.0,2f..15f),number(c,"focal",4.0,1f..8f)))
    }
}
