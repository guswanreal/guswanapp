package com.guswan.motion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

internal val Ink = Color(0xFF111315)
internal val Panel = Color(0xFF1C2024)
internal val Accent = Color(0xFFFFBD69)
internal val Text = Color(0xFFF4F5F6)
internal val Muted = Color(0xFFB1BAC4)
internal val Line = Color(0xFF78838E)
private val KeyframeIcon = ImageVector.Builder("Keyframe", 24.dp, 24.dp, 24f, 24f).apply {
    path(fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = 2f) {
        moveTo(12f, 3f); lineTo(21f, 12f); lineTo(12f, 21f); lineTo(3f, 12f); close()
    }
}.build()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { MotionTheme { EditorApp() } }
    }
}

@Composable
private fun MotionTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Ink, secondary = Accent, onSecondary = Ink,
        primaryContainer=Color(0xFF44351F),onPrimaryContainer=Accent,
        secondaryContainer=Color(0xFF44351F),onSecondaryContainer=Accent,
        tertiary=Accent,onTertiary=Ink,tertiaryContainer=Panel,onTertiaryContainer=Text,
        background = Ink, onBackground = Text, surface = Panel, onSurface = Text,
        surfaceVariant = Panel, onSurfaceVariant = Muted, outline = Line,
        surfaceTint=Color.Transparent,surfaceContainer=Panel,surfaceContainerLow=Ink,surfaceContainerLowest=Ink,
        surfaceContainerHigh=Color(0xFF292E33),surfaceContainerHighest=Color(0xFF353C43),
        error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
    ), content = content)
}

internal fun timeLabel(ms: Int): String = String.format(Locale.US, "%02d:%02d.%02d",
    ms / 60000, ms / 1000 % 60, ms % 1000 / 10)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditorApp() {
    val context = LocalContext.current
    val largeText = LocalDensity.current.fontScale > 1.4f
    val scope = rememberCoroutineScope()
    val initial = remember {
        runCatching {
            val file = File(context.filesDir, "autosave.gwm")
            val atomic = android.util.AtomicFile(file)
            if (file.exists() || File(file.path + ".bak").exists()) {
                val raw = atomic.openRead().use { it.readProjectText() }
                try { ProjectCodec.decode(raw) }
                catch (t: Exception) {
                    File(context.filesDir, "recovery-${System.currentTimeMillis()}.gwm").writeText(raw)
                    throw t
                }
            } else MotionProject()
        }
    }
    val editor = remember { EditorState(initial.getOrDefault(MotionProject())) }
    val renderer = remember { CompositionRenderer() }
    DisposableEffect(renderer) { onDispose { renderer.close() } }
    val library = remember { ProjectLibrary(context.filesDir) }
    var home by rememberSaveable { mutableStateOf(true) }
    var homeRefresh by remember { mutableIntStateOf(0) }
    var workspace by remember { mutableStateOf<String?>(null) }
    var newProjectDialog by remember { mutableStateOf(false) }
    val saveMutex = remember { Mutex() }
    var error by remember { mutableStateOf(initial.exceptionOrNull()?.let { "Proyek terakhir tidak dapat dibaca. Impor salinan .gwm untuk memulihkannya." }) }
    var sheet by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }
    var textDialog by remember { mutableStateOf(false) }
    var editingText by remember { mutableStateOf(false) }
    var projectDialog by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var saveFailed by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableFloatStateOf(0f) }
    var exportJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val snackbar = remember { SnackbarHostState() }
    var pendingProject by remember { mutableStateOf<MotionProject?>(null) }
    var pendingFrame by remember { mutableIntStateOf(0) }

    fun notify(message: String) { scope.launch { snackbar.showSnackbar(message) } }
    fun fail(t: Throwable) { error = t.message ?: "Operasi gagal. Coba lagi." }

    suspend fun persist(project: MotionProject) = withContext(Dispatchers.IO) {
        saveMutex.withLock {
            val data=library.save(project)
            val atomic = android.util.AtomicFile(File(context.filesDir,"autosave.gwm"))
            val output = atomic.startWrite()
            try { output.write(data.toByteArray()); atomic.finishWrite(output) }
            catch(t: Exception) { atomic.failWrite(output);throw t }
        }
    }
    fun goHome() {
        editor.playing=false;editor.finishGesture()
        scope.launch {
            busy="Menyimpan proyek…"
            try { persist(editor.project);homeRefresh++;home=true;workspace=null }
            catch(t: Exception) { fail(t) } finally { busy=null }
        }
    }
    fun startProject(project: MotionProject) { editor.open(project);home=false }
    BackHandler(enabled=!home && sheet==null && workspace==null && busy==null && !textDialog && !projectDialog) { goHome() }
    LaunchedEffect(Unit) {
        if(File(context.filesDir,"autosave.gwm").exists() && initial.isSuccess) {
            try { persist(editor.project);homeRefresh++ } catch(t: Exception) { fail(t) }
        }
    }

    val openProject = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            scope.launch {
                busy = "Membuka proyek…"
                try {
                    val project = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(it)?.use { stream ->
                            ProjectCodec.decode(stream.readProjectText()).also { p ->
                                p.layers.filter { l -> l.kind == LayerKind.IMAGE }.forEach { l ->
                                    require(l.image != null && CompositionRenderer().image(l.image) != null) {
                                        "Gambar dalam proyek rusak. Pilih salinan proyek lain."
                                    }
                                }
                            }
                        } ?: error("File tidak dapat dibuka.")
                    }
                    startProject(project.copy(id=java.util.UUID.randomUUID().toString())); notify("Proyek dibuka")
                } catch (t: Exception) { if (t is CancellationException) throw t; fail(t) }
                finally { busy = null }
            }
        }
    }
    val importImage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            scope.launch {
                busy = "Menyiapkan gambar…"
                try {
                    val encoded = withContext(Dispatchers.IO) {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        context.contentResolver.openInputStream(it)?.use { s -> BitmapFactory.decodeStream(s, null, bounds) }
                        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Format gambar tidak didukung." }
                        var sample = 1
                        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                        val bitmap = context.contentResolver.openInputStream(it)?.use { s ->
                            BitmapFactory.decodeStream(s, null, BitmapFactory.Options().apply { inSampleSize = sample })
                        } ?: error("Gambar tidak dapat dibaca.")
                        try {
                            ByteArrayOutputStream().use { out ->
                                check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out))
                                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                            }
                        } finally { bitmap.recycle() }
                    }
                    require(ProjectCodec.encode(editor.project).length + encoded.length < 24_000_000) {
                        "Proyek terlalu besar. Hapus beberapa gambar sebelum menambah gambar baru."
                    }
                    editor.add(LayerKind.IMAGE, image = encoded); sheet = "properties"
                } catch (t: Exception) { if (t is CancellationException) throw t; fail(t) }
                finally { busy = null }
            }
        }
    }
    val importVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { scope.launch {
            busy="Menyiapkan video…"
            try {
                require(editor.project.layers.size<40) { "Maksimum 40 layer." }
                val video = withContext(Dispatchers.IO) {
                    val data=context.contentResolver.openInputStream(it)?.use { stream ->
                        val out=ByteArrayOutputStream();val buffer=ByteArray(16384)
                        while(true) { val count=stream.read(buffer);if(count<0) break
                            require(out.size()+count<=12_000_000) { "Video maksimum 12 MB. Gunakan potongan video lebih pendek." }
                            out.write(buffer,0,count) }
                        out.toByteArray()
                    } ?: error("Video tidak dapat dibaca.")
                    val metadata=android.media.MediaMetadataRetriever()
                    try {
                        metadata.setDataSource(context,it)
                        val duration=metadata.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull()
                            ?.coerceIn(1,3_600_000) ?: error("Durasi video tidak valid.")
                        var width=metadata.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                        var height=metadata.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                        require(width in 1..8192 && height in 1..8192) { "Resolusi video tidak didukung." }
                        if(metadata.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() in listOf(90,270)) {
                            val swap=width;width=height;height=swap
                        }
                        MotionLayer(kind=LayerKind.VIDEO,name="Video ${editor.project.layers.count { l -> l.kind==LayerKind.VIDEO }+1}",
                            video=Base64.encodeToString(data,Base64.NO_WRAP),sourceDurationMs=duration,mediaWidth=width,mediaHeight=height,
                            endMs=minOf(editor.project.durationMs,duration))
                    } finally { metadata.release() }
                }
                val next=editor.project.copy(layers=editor.project.layers+video)
                require(ProjectCodec.encode(next).length<=24_000_000) { "Proyek maksimum 24 MB. Hapus media lain dahulu." }
                editor.change(next);editor.selectedId=video.id;sheet="properties"
                notify("Video ditambahkan tanpa audio")
            } catch(t: Exception) { if(t is CancellationException) throw t;fail(t) } finally { busy=null }
        } }
    }
    val importObj = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { scope.launch {
            busy="Membaca model OBJ…"
            try {
                require(editor.project.layers.size<40) { "Maksimum 40 layer." }
                val mesh=withContext(Dispatchers.IO) { context.contentResolver.openInputStream(it)?.use { stream ->
                    MeshData.obj(stream.readProjectText(1_000_000)) } ?: error("OBJ tidak dapat dibuka.") }
                val layer=MotionLayer(kind=LayerKind.MESH,name="Model OBJ",mesh=mesh,endMs=editor.project.durationMs,color=0xFFFFBD69.toInt())
                editor.change(editor.project.copy(layers=editor.project.layers+layer));editor.selectedId=layer.id
            } catch(t: Exception) { if(t is CancellationException) throw t;fail(t) } finally { busy=null }
        } }
    }
    val saveProject = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val snapshot = pendingProject
        pendingProject = null
        if (uri != null && snapshot != null) scope.launch {
            busy = "Menyimpan proyek…"
            try {
                withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri)?.use {
                    it.write(ProjectCodec.encode(snapshot).toByteArray())
                } ?: error("Lokasi penyimpanan tidak dapat ditulis.") }
                notify("Salinan proyek .gwm disimpan")
            } catch (t: Exception) { if (t is CancellationException) throw t; fail(t) }
            finally { busy = null }
        }
    }
    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        val snapshot = pendingProject
        val at = pendingFrame
        pendingProject = null
        if (uri != null && snapshot != null) scope.launch {
            busy = "Mengekspor frame…"
            try {
                withContext(Dispatchers.IO) {
                    val bitmap = CompositionRenderer().use { it.frame(snapshot, at) }
                    try { context.contentResolver.openOutputStream(uri)?.use {
                        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
                    } ?: error("Lokasi penyimpanan tidak dapat ditulis.") }
                    finally { bitmap.recycle() }
                }
                notify("Frame PNG disimpan")
            } catch (t: Exception) { if (t is CancellationException) throw t; fail(t) }
            finally { busy = null }
        }
    }
    val saveVideo = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        val snapshot = pendingProject
        pendingProject = null
        if (uri != null && snapshot != null) {
            exportJob = scope.launch {
                busy = "Mengekspor MP4…"; progress = 0f
                val temp = File(context.cacheDir, "export-${System.nanoTime()}.mp4")
                try {
                    withContext(Dispatchers.Default) {
                        VideoExporter.export(snapshot, temp) { value -> scope.launch { progress = value } }
                    }
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                            ?: error("Lokasi penyimpanan tidak dapat ditulis.")
                    }
                    notify("Video MP4 disimpan")
                } catch (t: Exception) {
                    withContext(kotlinx.coroutines.NonCancellable + Dispatchers.IO) {
                        runCatching { android.provider.DocumentsContract.deleteDocument(context.contentResolver, uri) }
                    }
                    if (t is CancellationException) notify("Ekspor dibatalkan") else fail(t)
                } finally { temp.delete(); busy = null; exportJob = null }
            }
        }
    }

    LaunchedEffect(editor.project,home) {
        if(home) return@LaunchedEffect
        saving = true; saveFailed = false
        delay(400)
        try {
            val snapshot = editor.project
            persist(snapshot)
        } catch (t: Exception) {
            if (t is CancellationException) throw t
            saveFailed = true; error = "Simpan otomatis gagal. Ekspor salinan proyek melalui menu Simpan."
        } finally { saving = false }
    }
    LaunchedEffect(editor.playing) {
        if (editor.playing) {
            if (editor.cursorMs >= editor.project.durationMs - 34) editor.cursorMs = 0
            val start = withFrameNanos { it }
            val offset = editor.cursorMs
            while (editor.playing) {
                val now = withFrameNanos { it }
                val at = offset + ((now - start) / 1_000_000).toInt()
                editor.cursorMs = at.coerceAtMost(editor.project.durationMs - 1)
                if (at >= editor.project.durationMs) editor.playing = false
            }
        }
    }

    if(home) HomeScreen(library,homeRefresh,onOpen={id -> scope.launch {
        busy="Membuka proyek…"
        try { startProject(withContext(Dispatchers.IO) { library.open(id) }) }
        catch(t: Exception) { fail(t) } finally { busy=null }
    }},onNew={newProjectDialog=true},onStudio={startProject(MotionProject.scene3D());workspace="studio"},
        onImport={openProject.launch(arrayOf("*/*"))},onExample={startProject(MotionProject.example())},
        onDelete={id -> scope.launch {
            try { withContext(Dispatchers.IO) { saveMutex.withLock { library.delete(id) } }
                if(editor.project.id==id) {
                    editor.open(MotionProject())
                    withContext(Dispatchers.IO) { android.util.AtomicFile(File(context.filesDir,"autosave.gwm")).delete() }
                }
                homeRefresh++
            } catch(t: Exception) { fail(t) }
        }},onDuplicate={id -> scope.launch {
            busy="Menyalin proyek…"
            try { withContext(Dispatchers.IO) { saveMutex.withLock {
                val project=library.open(id)
                library.save(project.copy(id=java.util.UUID.randomUUID().toString(),name="${project.name} salinan".take(80)))
            } };homeRefresh++ }
            catch(t: Exception) { fail(t) } finally { busy=null }
        }})

    if(!home) Scaffold(containerColor = Ink, snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            Column(Modifier.statusBarsPadding()) {
                Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(start = 16.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    ToolIcon(Icons.Outlined.Home,"Beranda") { goHome() }
                    Column(Modifier.weight(1f).heightIn(min = 48.dp).clickable { projectDialog = true }.padding(vertical = 8.dp)) {
                        Text("GUSWAN / MOTION", fontSize = 11.sp, color = Accent, fontWeight = FontWeight.Bold)
                        Text(editor.project.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    }
                    ToolIcon(Icons.AutoMirrored.Outlined.Undo, "Urungkan", editor.canUndo) { editor.undo() }
                    ToolIcon(Icons.AutoMirrored.Outlined.Redo, "Ulangi", editor.canRedo) { editor.redo() }
                    Box {
                        ToolIcon(Icons.Outlined.MoreVert, "Menu proyek") { menu = true }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text={Text("Beranda proyek")},onClick={menu=false;goHome()})
                            DropdownMenuItem(text = { Text("Pengaturan proyek") }, onClick = { menu = false; projectDialog = true })
                            DropdownMenuItem(text = { Text("Simpan salinan .gwm") }, onClick = {
                                menu = false; editor.playing = false; pendingProject = editor.project
                                saveProject.launch("${editor.project.name}.gwm")
                            })
                            DropdownMenuItem(text = { Text("Buka proyek .gwm") }, onClick = { menu = false; confirm = "open" })
                            DropdownMenuItem(text = { Text("Proyek kosong") }, onClick = { menu = false; confirm = "new" })
                            DropdownMenuItem(text = { Text("Muat contoh animasi") }, onClick = { menu = false; confirm = "demo" })
                        }
                    }
                }
                HorizontalDivider(color = Panel)
            }
        }, bottomBar = {
            Surface(color = Panel) {
                EditorTools(editor, onAdd = { sheet = "add" }, onProperties = { sheet = "properties" },
                    onAdvanced={editor.playing=false;sheet="tools"},
                    onExport = { editor.playing = false; sheet = "export" })
            }
        }) { insets ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(insets)) {
            val wide = maxWidth >= 600.dp || maxWidth > maxHeight * 1.25f
            val compactHeight = maxHeight < 600.dp
            val rightPanelWidth = minOf(320.dp, maxWidth * .42f)
            if (wide) {
                var rightPanel by remember { mutableIntStateOf(0) }
                Row(Modifier.fillMaxSize()) {
                    Column(Modifier.weight(1f)) {
                        CompositionPreview(editor, renderer, Modifier.weight(1f))
                        Transport(editor)
                    }
                    VerticalDivider(color = Line)
                    Column(Modifier.width(rightPanelWidth).fillMaxHeight()) {
                        Row(Modifier.fillMaxWidth()) {
                            listOf("Timeline", "Properti").forEachIndexed { index, title ->
                                TextButton(onClick = { rightPanel = index }, modifier = Modifier.weight(1f)) {
                                    Text(title, color = if (rightPanel == index) Accent else Muted)
                                }
                            }
                        }
                        Box(Modifier.weight(1f)) {
                            if (rightPanel == 0) Timeline(editor, Modifier.fillMaxSize(), showHeader = false)
                            else Inspector(editor, onEditText = { editingText = true; textDialog = true })
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        if (!largeText) Text("${editor.project.width} × ${editor.project.height}  /  30 fps", fontSize = 12.sp, color = Muted,
                            modifier = Modifier.weight(1f), maxLines = 2)
                        Text(if (saveFailed) "Simpan gagal" else if (saving) "Menyimpan…" else "Tersimpan di HP",
                            fontSize = 12.sp, color = if (saveFailed) MaterialTheme.colorScheme.error else Muted,
                            modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 2)
                    }
                    CompositionPreview(editor, renderer, Modifier.weight(1f))
                    Transport(editor)
                    if (largeText) {
                        OutlinedButton(onClick = { sheet = "timeline" },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp)) { Text("Timeline · ${editor.project.layers.size} layer") }
                    } else Timeline(editor, Modifier.height(if (compactHeight) 168.dp else 232.dp))
                }
            }
        }
    }
    if (sheet != null) {
        ModalBottomSheet(onDismissRequest = { editor.finishGesture(); sheet = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Panel) {
            Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.End) {
                TextButton(onClick={editor.finishGesture();sheet=null}) { Text("Tutup panel") }
            }
            when (sheet) {
                "add" -> Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("Tambah layer", style = MaterialTheme.typography.titleLarge)
                    Text("Layer baru tampil sepanjang komposisi.", color = Muted, modifier = Modifier.padding(vertical = 8.dp))
                    ActionRow(Icons.Outlined.TextFields, "Teks", "Tulis judul atau keterangan") {
                        sheet = null; editingText = false; textDialog = true
                    }
                    ActionRow(Icons.Outlined.CropSquare, "Persegi", "Bentuk dengan sudut membulat") {
                        runCatching { editor.add(LayerKind.RECTANGLE) }.onFailure(::fail); sheet = "properties"
                    }
                    ActionRow(Icons.Outlined.Circle, "Lingkaran", "Bentuk lingkaran berwarna") {
                        runCatching { editor.add(LayerKind.CIRCLE) }.onFailure(::fail); sheet = "properties"
                    }
                    ActionRow(Icons.Outlined.Image, "Gambar", "Pilih PNG, JPEG, atau WebP dari HP") {
                        sheet = null; importImage.launch(arrayOf("image/*"))
                    }
                    ActionRow(Icons.Outlined.Movie,"Video","Klip maksimum 12 MB, ditambahkan tanpa audio") { sheet=null;importVideo.launch(arrayOf("video/*")) }
                    ActionRow(Icons.Outlined.ViewInAr,"Objek 3D","Kubus, bola, bidang dan impor OBJ") { sheet=null;workspace="studio" }
                }
                "tools" -> Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("Alat komposisi",style=MaterialTheme.typography.titleLarge)
                    ActionRow(Icons.Outlined.ShowChart,"Graph & Flow","Graph nilai, kecepatan dan handle Bézier") { sheet=null;workspace="graph" }
                    ActionRow(Icons.Outlined.Speed,"Time remap","Speed ramp, freeze dan reverse") { sheet=null;workspace="time" }
                    ActionRow(Icons.Outlined.ViewInAr,"Studio 3D","Objek, kamera orbit dan transform XYZ") { sheet=null;workspace="studio" }
                    ActionRow(Icons.Outlined.Face,"Face tracking","Lacak wajah dari layer video ke keyframe 3D") { sheet=null;workspace="tracking" }
                    ActionRow(Icons.Outlined.Info,"Fitur & panduan","Fitur tersedia dan perbandingan AE / Blender") { sheet=null;workspace="features" }
                    Spacer(Modifier.height(24.dp))
                }
                "properties" -> Box(Modifier.fillMaxWidth().fillMaxHeight(.85f)) {
                    Inspector(editor, onEditText = { editingText = true; textDialog = true })
                }
                "timeline" -> Column(Modifier.fillMaxWidth().fillMaxHeight(.85f)) {
                    Transport(editor)
                    Timeline(editor, Modifier.weight(1f))
                }
                "export" -> Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Text("Ekspor komposisi", style = MaterialTheme.typography.titleLarge)
                    Text("${timeLabel(editor.project.durationMs)} · ${editor.project.layers.size} layer", color = Muted,
                        modifier = Modifier.padding(vertical = 8.dp))
                    ActionRow(Icons.Outlined.Movie, "Video MP4", "H.264 · 30 fps · tanpa audio · sisi panjang 960 px (persegi 720 px)") {
                        sheet = null; pendingProject = editor.project; saveVideo.launch("${editor.project.name}.mp4")
                    }
                    ActionRow(Icons.Outlined.Image, "Frame PNG", "Resolusi asli, pada ${timeLabel(editor.cursorMs)}") {
                        sheet = null; pendingProject = editor.project; pendingFrame = editor.cursorMs
                        savePng.launch("${editor.project.name}-${editor.cursorMs}.png")
                    }
                    ActionRow(Icons.Outlined.Save, "Proyek .gwm", "Semua layer, gambar, dan keyframe untuk diedit lagi") {
                        sheet = null; pendingProject = editor.project; saveProject.launch("${editor.project.name}.gwm")
                    }
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
    if (textDialog) {
        var value by remember { mutableStateOf(if (editingText) editor.selected?.text.orEmpty() else "") }
        AlertDialog(onDismissRequest = { textDialog = false }, title = { Text(if (editingText) "Edit teks" else "Layer teks") },
            text = { OutlinedTextField(value, { value = it.take(300) }, label = { Text("Teks komposisi") },
                minLines = 3, maxLines = 6, supportingText = { Text("${value.length}/300 karakter") }) },
            confirmButton = { TextButton(enabled = value.isNotBlank(), onClick = {
                runCatching {
                    if (editingText) editor.updateLayer { it.copy(text = value, name = value.lines().first().take(24)) }
                    else editor.add(LayerKind.TEXT, value)
                }.onFailure(::fail)
                textDialog = false; sheet = "properties"
            }) { Text("Terapkan") } }, dismissButton = { TextButton(onClick = { textDialog = false }) { Text("Batal") } })
    }
    if (projectDialog) ProjectSettings(editor.project, onDismiss = { projectDialog = false }) { next ->
        editor.change(next); editor.cursorMs = editor.cursorMs.coerceAtMost(next.durationMs - 1); projectDialog = false
    }
    if(newProjectDialog) {
        val draft=remember { MotionProject() }
        ProjectSettings(draft,onDismiss={newProjectDialog=false}) { next -> startProject(next);newProjectDialog=false }
    }
    workspace?.let { active ->
        WorkspaceWindow(when(active) { "graph"->"Graph & Flow";"time"->"Time remap";"studio"->"Studio 3D";"tracking"->"Face tracking";else->"Fitur & panduan" },
            onClose={editor.finishGesture();workspace=null}) {
            when(active) {
                "graph"->GraphPanel(editor)
                "time"->TimeRemapPanel(editor)
                "studio"->StudioPanel(editor,renderer) { importObj.launch(arrayOf("*/*")) }
                "tracking"->TrackingPanel(editor) { source ->
                    val snapshot=editor.project
                    workspace=null
                    exportJob=scope.launch {
                        busy="Melacak wajah…";progress=0f
                        try {
                            val result=withContext(Dispatchers.Default) { FaceTracking.scan(snapshot,source) { value -> scope.launch { progress=value } } }
                            editor.change(snapshot.copy(layers=snapshot.layers+result.layer,camera=Camera3D(0f,0f,5f,5f)))
                            editor.selectedId=result.layer.id
                            notify("Tracking selesai: wajah pada ${result.detected}/${result.sampled} frame sampel")
                        } catch(t: Exception) { if(t !is CancellationException) fail(t) }
                        finally { busy=null;exportJob=null }
                    }
                }
                else->FeatureCatalogue()
            }
        }
    }
    confirm?.let { action ->
        AlertDialog(onDismissRequest = { confirm = null }, title = { Text("Ganti proyek aktif?") },
            text = { Text("Proyek ini tetap tersimpan di Beranda. Ekspor salinan .gwm untuk cadangan terpisah.") },
            confirmButton = { TextButton(onClick = {
                scope.launch {
                try { persist(editor.project)
                when (action) {
                    "open" -> { editor.playing = false; openProject.launch(arrayOf("application/json", "application/octet-stream", "*/*")) }
                    "new" -> startProject(MotionProject())
                    "demo" -> { startProject(MotionProject.example()); editor.cursorMs = 2200 }
                }
                } catch(t: Exception) { fail(t) }
                }
                confirm = null
            }) { Text("Lanjutkan") } }, dismissButton = { TextButton(onClick = { confirm = null }) { Text("Batal") } })
    }
    busy?.let { operation ->
        AlertDialog(onDismissRequest = {}, title = { Text(operation) }, text = {
            Column {
                if (exportJob != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Text("${(progress * 100).toInt()}%", modifier = Modifier.padding(top = 12.dp))
                } else LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("Tunggu sampai proses selesai.", color = Muted, modifier = Modifier.padding(top = 12.dp))
            }
        }, confirmButton = {
            if (exportJob != null) TextButton(onClick = { exportJob?.cancel() }) { Text("Batalkan proses") }
        })
    }
    error?.let { message ->
        AlertDialog(onDismissRequest = { error = null }, title = { Text("Operasi belum berhasil") },
            text = { Text(message) }, confirmButton = { TextButton(onClick = { error = null }) { Text("Mengerti") } })
    }
}

@Composable
internal fun ToolIcon(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    IconButton(onClick, enabled = enabled, modifier = Modifier.size(48.dp)) { Icon(icon, label) }
}

@Composable
private fun RowScope.BottomTool(icon: ImageVector, label: String, enabled: Boolean = true,
    active: Boolean = false, onClick: () -> Unit) {
    TextButton(onClick, enabled = enabled, shape = RoundedCornerShape(8.dp), modifier = Modifier.weight(1f).heightIn(min = 56.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = if (!enabled) Muted.copy(alpha = .38f) else if (active) Accent else Text)
            Text(label, fontSize = 11.sp, maxLines = 2, textAlign = TextAlign.Center,
                color = if (!enabled) Muted.copy(alpha = .38f) else if (active) Accent else Text)
        }
    }
}

private data class EditorTool(val icon: ImageVector, val label: String, val enabled: Boolean = true,
    val active: Boolean = false, val action: () -> Unit)

@Composable
private fun EditorTools(editor: EditorState, onAdd: () -> Unit, onProperties: () -> Unit, onAdvanced: () -> Unit, onExport: () -> Unit) {
    val tools = listOf(
        EditorTool(Icons.Outlined.Add, "Tambah", action = onAdd),
        EditorTool(Icons.Outlined.Tune, "Properti", editor.selected != null, action = onProperties),
        EditorTool(Icons.Outlined.Tune,"Alat",action=onAdvanced),
        EditorTool(Icons.Outlined.FileUpload, "Ekspor", editor.project.layers.isNotEmpty(), action = onExport),
    )
    val columns = if (LocalDensity.current.fontScale > 1.4f) 2 else 4
    Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp)) {
        tools.chunked(columns).forEach { group ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                group.forEach { tool -> BottomTool(tool.icon, tool.label, tool.enabled, tool.active, tool.action) }
            }
        }
    }
}

@Composable
private fun ActionRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
internal fun CompositionPreview(editor: EditorState, renderer: CompositionRenderer, modifier: Modifier = Modifier, grid: Boolean = false) {
    val snapshot=editor.project
    val at=editor.cursorMs
    val selected=if(editor.playing) null else editor.selectedId
    val hasVideo=snapshot.layers.any { it.kind==LayerKind.VIDEO }
    val videoPreview by produceState<Pair<Bitmap?,String?>>(null to null,snapshot,at,selected,grid) {
        if(hasVideo) value=withContext(Dispatchers.Default) {
            try {
                val ratio=snapshot.width.toFloat()/snapshot.height
                val width=if(ratio>=1) 720 else (720*ratio).toInt().coerceAtLeast(1)
                val height=if(ratio>=1) (720/ratio).toInt().coerceAtLeast(1) else 720
                val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
                renderer.draw(android.graphics.Canvas(bitmap),snapshot,at,selected,width,height,grid)
                bitmap to null
            } catch(t: Exception) { null to "Preview video gagal dibaca. Coba klip MP4 H.264 lain." }
        }
    }
    BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center) {
        val ratio = editor.project.width.toFloat() / editor.project.height
        val w = minOf(maxWidth, maxHeight * ratio)
        val h = w / ratio
        Box(Modifier.size(w, h).clip(RoundedCornerShape(2.dp)).border(1.dp, Line)) {
            val project = editor.project
            val cursor = editor.cursorMs
            Canvas(Modifier.fillMaxSize()
                .semantics { contentDescription = "Preview komposisi pada ${timeLabel(cursor)}. Pilih layer di timeline untuk mengedit." }
                .pointerInput(editor.selectedId, project.width, project.height) {
                    detectDragGestures(onDragEnd = { editor.finishGesture() }, onDragCancel = { editor.finishGesture() }) { change, amount ->
                        if (editor.selected?.locked == false) {
                            change.consume()
                            val p = editor.selected!!.poseAt(editor.cursorMs)
                            editor.pose(p.copy(x = (p.x + amount.x / size.width).coerceIn(-2f, 3f),
                                y = (p.y + amount.y / size.height).coerceIn(-2f, 3f)), continuous = true)
                        }
                    }
                }) {
                drawIntoCanvas {
                    if(hasVideo) videoPreview.first?.let { bitmap ->
                        it.nativeCanvas.drawBitmap(bitmap,null,android.graphics.RectF(0f,0f,size.width,size.height),null)
                    } else renderer.draw(it.nativeCanvas, project, cursor,
                        if (editor.playing) null else editor.selectedId, size.width.toInt(), size.height.toInt(),grid)
                }
            }
            if(hasVideo && (videoPreview.first==null || videoPreview.second!=null)) Text(videoPreview.second ?: "Menyiapkan preview…",
                color=Text,modifier=Modifier.align(Alignment.Center).background(Panel).padding(12.dp),fontSize=12.sp)
            if (project.layers.isEmpty()) Column(Modifier.align(Alignment.Center).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Layers, null, tint = Muted, modifier = Modifier.size(32.dp))
                Text("Kanvas kosong", color = Text, modifier = Modifier.padding(top = 12.dp), fontWeight = FontWeight.SemiBold)
                Text("Tambah teks, bentuk, atau gambar untuk mulai.", color = Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

@Composable
internal fun Transport(editor: EditorState) {
    if (LocalDensity.current.fontScale > 1.4f) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(timeLabel(editor.cursorMs), color = Accent, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text(timeLabel(editor.project.durationMs), color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
            Box(Modifier.fillMaxWidth().heightIn(min = 56.dp), contentAlignment = Alignment.Center) { TransportButtons(editor) }
        }
        return
    }
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(timeLabel(editor.cursorMs), color = Accent, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        TransportButtons(editor)
        Text(timeLabel(editor.project.durationMs), fontSize = 12.sp, color = Muted,
            fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f).padding(end = 8.dp),
            textAlign = TextAlign.End, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TransportButtons(editor: EditorState) {
    Row(verticalAlignment = Alignment.CenterVertically) {
            ToolIcon(Icons.Outlined.SkipPrevious, "Keyframe sebelumnya") {
                editor.playing = false
                editor.cursorMs = editor.selected?.keyPositions()?.map { it.second }?.lastOrNull { it < editor.cursorMs } ?: 0
            }
            FilledIconButton(onClick = { editor.playing = !editor.playing }, enabled = editor.project.layers.isNotEmpty(),
                modifier = Modifier.size(48.dp), shape = RoundedCornerShape(12.dp)) {
                Icon(if (editor.playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                    if (editor.playing) "Jeda preview" else "Putar preview")
            }
            ToolIcon(Icons.Outlined.SkipNext, "Keyframe berikutnya") {
                editor.playing = false
                editor.cursorMs = (editor.selected?.keyPositions()?.map { it.second }?.firstOrNull { it > editor.cursorMs }
                    ?: (editor.project.durationMs - 1)).coerceAtMost(editor.project.durationMs - 1)
            }
    }
}

@Composable
private fun Timeline(editor: EditorState, modifier: Modifier = Modifier, showHeader: Boolean = true) {
    val labelWidth = if (LocalDensity.current.fontScale > 1.4f) 140.dp else 96.dp
    Column(modifier.fillMaxWidth().background(Panel)) {
        if (showHeader) Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Timeline", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text("${editor.project.layers.size} layer", color = Muted, fontSize = 12.sp)
        }
        Slider(value = editor.cursorMs.toFloat(), onValueChange = {
            editor.playing = false
            editor.cursorMs = ((it / (1000f / 30)).roundToInt() * (1000f / 30)).toInt()
                .coerceIn(0, editor.project.durationMs - 1)
        }, valueRange = 0f..(editor.project.durationMs - 1).toFloat(),
            modifier = Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 12.dp)
                .semantics { contentDescription = "Posisi waktu komposisi" })
        if (editor.project.layers.isEmpty()) {
            Text("Belum ada layer. Ketuk Tambah di bawah.", color = Muted, fontSize = 12.sp,
                modifier = Modifier.padding(16.dp))
        } else LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(editor.project.layers.reversed(), key = { it.id }) { layer ->
                val active = layer.id == editor.selectedId
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp)
                    .background(if (active) Accent.copy(alpha = .08f) else Color.Transparent),
                    verticalAlignment = Alignment.CenterVertically) {
                    ToolIcon(if (layer.visible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                        if (layer.visible) "Sembunyikan ${layer.name}" else "Tampilkan ${layer.name}") { editor.toggleVisibility(layer.id) }
                    Column(Modifier.width(labelWidth).heightIn(min = 48.dp).clickable { editor.selectedId = layer.id }
                        .padding(vertical = 6.dp), verticalArrangement = Arrangement.Center) {
                        Text(layer.name, fontSize = 12.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (active) Accent else Text)
                        Text(if (layer.locked) "Terkunci" else "${layer.keys.size} keyframe", fontSize = 10.sp, color = Muted)
                    }
                    Canvas(Modifier.weight(1f).height(48.dp).padding(horizontal = 12.dp)
                        .pointerInput(layer.id, editor.project.durationMs) {
                            detectTapGestures { offset ->
                                editor.playing = false; editor.selectedId = layer.id
                                editor.cursorMs = (offset.x / size.width * editor.project.durationMs).toInt()
                                    .coerceIn(0, editor.project.durationMs - 1)
                            }
                        }) {
                        val duration = editor.project.durationMs.toFloat()
                        val left = size.width * layer.startMs / duration
                        val right = size.width * layer.endMs / duration
                        drawRect(Line.copy(alpha = .3f), Offset(0f, size.height / 2 - 1), Size(size.width, 2f))
                        drawRoundRect(if (active) Accent else Line, Offset(left, 7.dp.toPx()),
                            Size((right - left).coerceAtLeast(2f), size.height - 14.dp.toPx()),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                        layer.keyPositions().forEach { (_,time) ->
                            val x = size.width * time / duration
                            val y = size.height / 2
                            val r = 5.dp.toPx()
                            val diamond = Path().apply { moveTo(x, y - r); lineTo(x + r, y); lineTo(x, y + r); lineTo(x - r, y); close() }
                            drawPath(diamond, Ink)
                        }
                        val x = size.width * editor.cursorMs / duration
                        drawLine(Text, Offset(x, 0f), Offset(x, size.height), strokeWidth = 2.dp.toPx())
                    }
                }
            }
        }
    }
}

@Composable
private fun Inspector(editor: EditorState, onEditText: () -> Unit) {
    val layer = editor.selected
    if (layer == null) {
        Column(Modifier.padding(24.dp)) {
            Text("Properti layer", style = MaterialTheme.typography.titleLarge)
            Text("Tambah layer atau pilih layer di timeline.", color = Muted, modifier = Modifier.padding(top = 12.dp))
        }
        return
    }
    var tab by remember { mutableIntStateOf(0) }
    val p = layer.poseAt(editor.cursorMs)
    val keyTime=layer.keyTimeAt(editor.cursorMs)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).imePadding()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text(layer.name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f),
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            ToolIcon(if (layer.locked) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
                if (layer.locked) "Buka kunci layer" else "Kunci layer") { editor.toggleLock(layer.id) }
        }
        if (layer.locked) Text("Layer terkunci. Buka kunci untuk mengedit.", color = Accent, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("Transform", "Tampilan", "Waktu").forEachIndexed { index, title ->
                TextButton(onClick = { editor.finishGesture(); tab = index }, modifier = Modifier.weight(1f)) {
                    Text(title, color = if (tab == index) Accent else Muted, fontSize = 12.sp,
                        textAlign = TextAlign.Center, maxLines = 2)
                }
            }
        }
        if (tab == 0) {
            Text(if (layer.keys.isEmpty()) "Nilai tetap. Tambahkan keyframe untuk animasi."
                else "Perubahan menyimpan keyframe pada ${timeLabel(keyTime)}${if(layer.timeRemap.isNotEmpty() && layer.kind!=LayerKind.VIDEO) " waktu sumber" else ""}.", color = Muted, fontSize = 12.sp)
            PropertySlider("Posisi X", "${(p.x * 100).roundToInt()}%", p.x, -1f..2f, !layer.locked,
                { editor.pose(p.copy(x = it), true) }, editor::finishGesture)
            PropertySlider("Posisi Y", "${(p.y * 100).roundToInt()}%", p.y, -1f..2f, !layer.locked,
                { editor.pose(p.copy(y = it), true) }, editor::finishGesture)
            PropertySlider("Skala", "${(p.scale * 100).roundToInt()}%", p.scale, .05f..4f, !layer.locked,
                { editor.pose(p.copy(scale = it), true) }, editor::finishGesture)
            PropertySlider("Rotasi", "${p.rotation.roundToInt()}°", p.rotation, -360f..360f, !layer.locked,
                { editor.pose(p.copy(rotation = it), true) }, editor::finishGesture)
            if(layer.kind.is3D) {
                PropertySlider("Kedalaman Z",String.format(Locale.US,"%.2f",p.z),p.z,-4f..4f,!layer.locked,
                    {editor.pose(p.copy(z=it),true)},editor::finishGesture)
                PropertySlider("Rotasi X","${p.rotationX.roundToInt()}°",p.rotationX,-360f..360f,!layer.locked,
                    {editor.pose(p.copy(rotationX=it),true)},editor::finishGesture)
                PropertySlider("Rotasi Y","${p.rotationY.roundToInt()}°",p.rotationY,-360f..360f,!layer.locked,
                    {editor.pose(p.copy(rotationY=it),true)},editor::finishGesture)
            }
            PropertySlider("Opasitas", "${(p.opacity * 100).roundToInt()}%", p.opacity, 0f..1f, !layer.locked,
                { editor.pose(p.copy(opacity = it), true) }, editor::finishGesture)
            OutlinedButton(onClick = { editor.toggleKeyframe() }, enabled = !layer.locked, modifier = Modifier.fillMaxWidth()) {
                Icon(KeyframeIcon, null); Spacer(Modifier.width(8.dp))
                Text(if (layer.keys.any { it.timeMs == keyTime }) "Hapus keyframe ini" else "Tambah keyframe")
            }
            if (layer.keys.isNotEmpty()) {
                Text("Kurva menuju keyframe ini", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
                val key = layer.keys.firstOrNull { it.timeMs == keyTime }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(Easing.LINEAR,Easing.SMOOTH,Easing.HOLD).forEach { easing ->
                        FilterChip(selected = key?.easing == easing, enabled = !layer.locked && key != null,
                            onClick = { editor.updateLayer { it.putKey(keyTime, p, easing) } },
                            label = { Text(when (easing) { Easing.LINEAR -> "Linear"; Easing.SMOOTH -> "Halus"; Easing.HOLD -> "Tahan"; Easing.BEZIER -> "Bézier" }, fontSize = 12.sp) })
                    }
                }
                Text("Gunakan tombol sebelum/berikut di preview untuk memilih keyframe tepat.", fontSize = 12.sp, color = Muted)
            }
        }
        if (tab == 1) {
            if (layer.kind == LayerKind.TEXT) OutlinedButton(onClick = onEditText,
                enabled = !layer.locked, modifier = Modifier.fillMaxWidth()) { Text("Edit isi teks") }
            if (layer.kind != LayerKind.IMAGE && layer.kind != LayerKind.VIDEO) {
                Text("Warna layer", color = Muted, modifier = Modifier.padding(top = 12.dp))
                val colors = listOf(0xFFF4F5F6, 0xFFFFBD69, 0xFF83D4C3, 0xFF151D24, 0xFFE99B9B)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    colors.forEach { color ->
                        IconButton(onClick = { editor.updateLayer { it.copy(color = color.toInt()) } }, enabled = !layer.locked,
                            modifier = Modifier.size(48.dp).semantics { contentDescription = "Warna #${color.toString(16).takeLast(6)}" }) {
                            Box(Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)).background(Color(color))
                                .border(if (layer.color == color.toInt()) 3.dp else 1.dp,
                                    if (layer.color == color.toInt()) Accent else Line, RoundedCornerShape(6.dp)),
                                contentAlignment = Alignment.Center) {
                                if (layer.color == color.toInt()) Icon(Icons.Outlined.Check, null,
                                    tint = if (color == 0xFF151D24) Text else Ink, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
            if (layer.kind in listOf(LayerKind.TEXT,LayerKind.RECTANGLE,LayerKind.CIRCLE)) PropertySlider("Bayangan", "${layer.shadow.roundToInt()} px", layer.shadow,
                0f..60f, !layer.locked, { editor.updateLayer(true) { l -> l.copy(shadow = it) } }, editor::finishGesture)
            PropertySlider("Brightness","${(layer.brightness*100).roundToInt()}%",layer.brightness,-1f..1f,!layer.locked,
                {value->editor.updateLayer(true) { it.copy(brightness=value) }},editor::finishGesture)
            if(!layer.kind.is3D) {
                PropertySlider("Saturation","${(layer.saturation*100).roundToInt()}%",layer.saturation,0f..2f,!layer.locked,
                    {value->editor.updateLayer(true) { it.copy(saturation=value) }},editor::finishGesture)
                Text("Blending",color=Muted,modifier=Modifier.padding(top=12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    BlendMode.entries.forEach { mode -> FilterChip(selected=layer.blend==mode,onClick={editor.updateLayer { it.copy(blend=mode) }},
                        enabled=!layer.locked,label={Text(mode.label)}) }
                }
            }
        }
        if (tab == 2) {
            Text("Rentang layer", style = MaterialTheme.typography.titleMedium)
            Text("${timeLabel(layer.startMs)} sampai ${timeLabel(layer.endMs)}", color = Muted, fontSize = 12.sp)
            PropertySlider("Mulai", timeLabel(layer.startMs), layer.startMs.toFloat(), 0f..(layer.endMs - 1).toFloat(),
                !layer.locked, { value -> editor.updateLayer(true) { it.copy(startMs = value.toInt()) } }, editor::finishGesture)
            PropertySlider("Selesai", timeLabel(layer.endMs), layer.endMs.toFloat(),
                (layer.startMs + 1).toFloat()..editor.project.durationMs.toFloat(), !layer.locked,
                { value -> editor.updateLayer(true) { it.copy(endMs = value.toInt()) } }, editor::finishGesture)
            Row {
                TextButton(onClick = { editor.reorder(true) }, enabled = !layer.locked) { Text("Naikkan layer") }
                TextButton(onClick = { editor.reorder(false) }, enabled = !layer.locked) { Text("Turunkan") }
            }
        }
        HorizontalDivider(Modifier.padding(vertical = 16.dp), color = Line.copy(alpha = .3f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { editor.duplicate() }, enabled = editor.project.layers.size < 40) {
                Icon(Icons.Outlined.ContentCopy, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Duplikat")
            }
            TextButton(onClick = { editor.delete() }, enabled = !layer.locked) {
                Icon(Icons.Outlined.DeleteOutline, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Hapus")
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
internal fun PropertySlider(label: String, formatted: String, value: Float, range: ClosedFloatingPointRange<Float>,
    enabled: Boolean, onChange: (Float) -> Unit, onFinished: () -> Unit) {
    Column(Modifier.padding(top = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp)
            Text(formatted, color = Accent, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        }
        Slider(value = value.coerceIn(range), onValueChange = onChange, onValueChangeFinished = onFinished,
            valueRange = range, enabled = enabled, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                .semantics { contentDescription = label })
    }
}

@Composable
private fun ProjectSettings(project: MotionProject, onDismiss: () -> Unit, onApply: (MotionProject) -> Unit) {
    var name by remember { mutableStateOf(project.name) }
    var seconds by remember { mutableStateOf((project.durationMs / 1000f).toString()) }
    var aspect by remember { mutableIntStateOf(if (project.width == project.height) 1 else if (project.width > project.height) 2 else 0) }
    val duration = seconds.toFloatOrNull()?.takeIf { it.isFinite() && it in 1f..30f }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Pengaturan proyek") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            OutlinedTextField(name, { name = it.take(80) }, label = { Text("Nama proyek") }, singleLine = true)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(seconds, { seconds = it }, label = { Text("Durasi (1–30 detik)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), isError = duration == null,
                supportingText = { if (duration == null) Text("Masukkan durasi antara 1 dan 30 detik.") })
            Text("Format kanvas", modifier = Modifier.padding(top = 12.dp), color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("9:16", "1:1", "16:9").forEachIndexed { i, label ->
                    FilterChip(aspect == i, { aspect = i }, label = { Text(label) })
                }
            }
            Text("Memendekkan durasi memangkas keyframe di luar komposisi. Urungkan untuk memulihkan.", fontSize = 12.sp, color = Muted)
        }
    }, confirmButton = { TextButton(enabled = name.isNotBlank() && duration != null, onClick = {
        val sizes = listOf(1080 to 1920, 1080 to 1080, 1920 to 1080)
        onApply(project.resizedDuration((duration!! * 1000).roundToInt()).copy(name = name,
            width = sizes[aspect].first, height = sizes[aspect].second))
    }) { Text("Terapkan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Preview(name = "HP", widthDp = 393, heightDp = 851, showBackground = true)
@Composable
private fun PhonePreview() = MotionTheme {
    val editor = remember { EditorState(MotionProject.example()).apply { cursorMs = 2200 } }
    Column(Modifier.fillMaxSize().background(Ink)) {
        Text("Guswan Motion · Contoh animasi", color = Text, modifier = Modifier.padding(16.dp))
        CompositionPreview(editor, remember { CompositionRenderer() }, Modifier.weight(1f))
        Transport(editor)
        Timeline(editor, Modifier.height(232.dp))
    }
}
