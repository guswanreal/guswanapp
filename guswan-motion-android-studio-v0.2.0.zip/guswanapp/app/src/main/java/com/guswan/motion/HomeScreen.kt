package com.guswan.motion

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(library: ProjectLibrary, refresh: Int, onOpen: (String) -> Unit, onNew: () -> Unit,
    onStudio: () -> Unit, onImport: () -> Unit, onExample: () -> Unit,
    onDelete: (String) -> Unit, onDuplicate: (String) -> Unit) {
    var entries by remember { mutableStateOf<List<ProjectEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var catalogue by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<ProjectEntry?>(null) }
    LaunchedEffect(refresh,retry) {
        loading = true; error = null
        try { entries = withContext(Dispatchers.IO) { library.list() } }
        catch(t: Exception) { error = "Daftar proyek gagal dibaca. Coba lagi atau impor salinan .gwm." }
        finally { loading = false }
    }
    Scaffold(containerColor=Ink, topBar={
        Column(Modifier.statusBarsPadding().padding(horizontal=20.dp,vertical=16.dp)) {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("GUSWAN / MOTION",color=Accent,fontSize=12.sp,fontWeight=FontWeight.Bold)
                    Text("Ruang kerja",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.SemiBold)
                }
                ToolIcon(Icons.Outlined.Info,"Fitur dan panduan") { catalogue = true }
            }
        }
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding),contentPadding=PaddingValues(start=20.dp,end=20.dp,bottom=32.dp),
            verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item {
                Surface(color=Panel,shape=RoundedCornerShape(12.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("Mulai dari sebuah ide.",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold)
                        Text("Susun layer, bentuk gerak, lalu render.",color=Muted,modifier=Modifier.padding(top=8.dp,bottom=16.dp))
                        Button(onClick=onNew,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(8.dp)) {
                            Icon(Icons.Outlined.Add,null); Spacer(Modifier.width(8.dp)); Text("Proyek baru")
                        }
                        OutlinedButton(onClick=onStudio,modifier=Modifier.fillMaxWidth().heightIn(min=52.dp),shape=RoundedCornerShape(8.dp)) {
                            Icon(Icons.Outlined.ViewInAr,null); Spacer(Modifier.width(8.dp)); Text("Studio 3D baru")
                        }
                        TextButton(onClick=onImport,modifier=Modifier.fillMaxWidth().heightIn(min=48.dp)) {
                            Icon(Icons.Outlined.FolderOpen,null); Spacer(Modifier.width(8.dp)); Text("Impor proyek .gwm")
                        }
                    }
                }
            }
            item {
                Text("Proyek di HP ini",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=12.dp))
                Text("Tersimpan otomatis. Ekspor .gwm untuk cadangan.",color=Muted,fontSize=12.sp)
            }
            if(entries.size > 3) item { OutlinedTextField(query,{query=it},label={Text("Cari proyek")},singleLine=true,modifier=Modifier.fillMaxWidth()) }
            if(loading) item {
                Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text("Membaca proyek…")
                }
            } else if(error != null) item {
                Text(error!!,color=MaterialTheme.colorScheme.error)
                TextButton(onClick={retry++}) { Text("Coba lagi") }
            } else if(entries.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(vertical=24.dp)) {
                    Text("Belum ada proyek",fontWeight=FontWeight.SemiBold)
                    Text("Buat komposisi pertama atau buka contoh untuk mempelajari keyframe.",color=Muted,modifier=Modifier.padding(top=8.dp))
                    TextButton(onClick=onExample,modifier=Modifier.heightIn(min=48.dp)) { Text("Buka contoh animasi") }
                }
            } else {
                val filtered = entries.filter { it.name.contains(query,ignoreCase=true) }
                if(filtered.isEmpty()) item { Text("Tidak ada proyek dengan nama itu.",color=Muted) }
                items(filtered,key={it.id}) { entry ->
                    Surface(color=Panel,shape=RoundedCornerShape(8.dp)) {
                        Column {
                            Row(Modifier.fillMaxWidth().clickable { onOpen(entry.id) }.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                                ProjectThumbnail(library,entry)
                                Column(Modifier.weight(1f).padding(start=12.dp)) {
                                    Text(entry.name,fontWeight=FontWeight.SemiBold,maxLines=2,overflow=TextOverflow.Ellipsis)
                                    Text("${entry.width} × ${entry.height} · ${entry.layers} layer",color=Muted,fontSize=12.sp)
                                    Text("${timeLabel(entry.durationMs)} · ${if(entry.threeD) "Scene 3D" else "Komposisi"}",color=Muted,fontSize=12.sp)
                                    Text(SimpleDateFormat("dd MMM, HH:mm",Locale.getDefault()).format(Date(entry.updated)),color=Muted,fontSize=11.sp)
                                }
                            }
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) {
                                ToolIcon(Icons.Outlined.ContentCopy,"Salin proyek ${entry.name}") { onDuplicate(entry.id) }
                                ToolIcon(Icons.Outlined.DeleteOutline,"Hapus proyek ${entry.name}") { deleting=entry }
                            }
                        }
                    }
                }
            }
        }
    }
    deleting?.let { entry -> AlertDialog(onDismissRequest={deleting=null},title={Text("Hapus proyek?")},
        text={Text("${entry.name} akan dihapus dari HP ini. Salinan .gwm yang sudah diekspor tetap tersedia.")},
        confirmButton={TextButton(onClick={onDelete(entry.id);deleting=null}) { Text("Hapus proyek") }},
        dismissButton={TextButton(onClick={deleting=null}) { Text("Batal") }}) }
    if(catalogue) WorkspaceWindow("Fitur & panduan",{catalogue=false}) { FeatureCatalogue() }
}

@Composable private fun ProjectThumbnail(library: ProjectLibrary, entry: ProjectEntry) {
    val bitmap by produceState<android.graphics.Bitmap?>(null,entry.id,entry.updated) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val project = library.open(entry.id)
                CompositionRenderer().use { it.frame(project,minOf(2000,project.durationMs-1),
                    if(project.width>=project.height) 160 else (160f*project.width/project.height).toInt().coerceAtLeast(1),
                    if(project.height>=project.width) 160 else (160f*project.height/project.width).toInt().coerceAtLeast(1)) }
            }.getOrNull()
        }
    }
    Box(Modifier.size(76.dp,88.dp).background(Ink,RoundedCornerShape(4.dp)),contentAlignment=Alignment.Center) {
        bitmap?.let { Image(it.asImageBitmap(),"Preview proyek ${entry.name}",Modifier.fillMaxSize()) }
            ?: Icon(if(entry.threeD) Icons.Outlined.ViewInAr else Icons.Outlined.Layers,null,tint=Muted)
    }
}

@Composable fun FeatureCatalogue() {
    val sections = listOf(
        "Tersedia di Guswan Motion 0.2" to listOf("Beranda dan banyak proyek lokal", "Layer teks, bentuk, gambar, video tanpa audio",
            "Keyframe posisi, skala, opasitas, rotasi XYZ dan kedalaman Z", "Graph nilai/kecepatan dan cubic Bézier", "Preset easing Flow bawaan",
            "Time remap, speed ramp, freeze dan reverse", "Studio 3D: kubus, bola, bidang, impor OBJ, kamera orbit", "Face tracking video: posisi, skala dan estimasi sudut kepala XYZ",
            "Brightness, saturation, shadow, blending Add/Multiply/Screen", "Undo/redo, PNG, MP4 H.264 dan proyek .gwm"),
        "Fitur After Effects yang belum tersedia" to listOf("Masking, rotoscoping dan keying/chroma key", "Camera tracking scene 3D, face mesh dan depth terkalibrasi",
            "Motion blur, optical flow, stabilisasi dan particles", "Audio, waveform, mixing dan sinkronisasi beat", "Precomposition, parenting, expressions dan scripting",
            "Text animator per karakter dan path/shape Bezier", "Plugin Adobe .aex/.jsx, proyek .aep dan integrasi Adobe"),
        "Fitur Blender yang belum tersedia" to listOf("Edit mesh vertex/edge/face, sculpt dan modifiers", "UV, texture/material nodes dan rigging", "Simulasi, ray tracing dan render Cycles/Eevee"),
        "Cara kerja" to listOf("Tambah layer, pilih di timeline lalu buka Properti.", "Buat minimal dua keyframe. Buka Alat > Graph & Flow untuk mengubah kurva menuju keyframe yang dipilih.",
            "Pilih layer animasi/video lalu buka Time remap. Kurva mengubah waktu sumber, termasuk hasil ekspor.",
            "Impor video pendek (maks. 12 MB). Pilih video lalu Face tracking. Wajah terbesar pada awal menjadi target; hasil dibake menjadi keyframe objek wireframe.",
            "Face tracking disampel 5 fps, berjalan di HP, dan mengestimasi pose kepala. Ini belum menghasilkan mesh wajah atau camera solve.",
            "Video dan gambar disertakan dalam .gwm. Batas proyek 24 MB; durasi komposisi 1–30 detik.",
            "Ekspor MP4 saat aplikasi tetap terbuka. Hasil tanpa audio; video memakai frame terdekat, tanpa optical flow.")
    )
    LazyColumn(Modifier.fillMaxSize().testTag("feature-list"),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        sections.forEach { (title,rows) ->
            item { Text(title,color=Accent,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=8.dp)) }
            items(rows) { Text(it,color=Text,modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)) }
        }
    }
}
