package com.guswan.motion

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import java.util.UUID

class EditorState(initial: MotionProject) {
    var project by mutableStateOf(initial)
        private set
    var selectedId by mutableStateOf(initial.layers.lastOrNull()?.id)
    var cursorMs by mutableIntStateOf(0)
    var playing by mutableStateOf(false)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    private val undo = ArrayDeque<MotionProject>()
    private val redo = ArrayDeque<MotionProject>()
    private var continuousStart: MotionProject? = null
    val selected: MotionLayer? get() = project.layers.find { it.id == selectedId }

    fun change(next: MotionProject, continuous: Boolean = false) {
        if (next == project) return
        playing = false
        if (continuous) {
            if (continuousStart == null) continuousStart = project
        } else {
            finishGesture()
            undo.addLast(project)
            if (undo.size > 60) undo.removeFirst()
            redo.clear()
        }
        project = next
        refreshHistory()
    }

    fun finishGesture() {
        continuousStart?.let { before ->
            if (before != project) {
                undo.addLast(before)
                if (undo.size > 60) undo.removeFirst()
                redo.clear()
            }
        }
        continuousStart = null
        refreshHistory()
    }

    fun updateLayer(continuous: Boolean = false, update: (MotionLayer) -> MotionLayer) {
        val layer = selected ?: return
        if (layer.locked) return
        change(project.copy(layers = project.layers.map { if (it.id == layer.id) update(it) else it }), continuous)
    }

    fun pose(value: Pose, continuous: Boolean = false) = updateLayer(continuous) { it.editPose(cursorMs, value) }

    fun add(kind: LayerKind, text: String = "Teks baru", image: String? = null) {
        require(project.layers.size < 40) { "Maksimum 40 layer per proyek." }
        val name = when (kind) {
            LayerKind.TEXT -> text.lines().first().take(24).ifBlank { "Teks" }
            LayerKind.RECTANGLE -> "Persegi"
            LayerKind.CIRCLE -> "Lingkaran"
            LayerKind.IMAGE -> "Gambar"
            LayerKind.VIDEO -> "Video"
            LayerKind.CUBE -> "Kubus"
            LayerKind.SPHERE -> "Bola"
            LayerKind.PLANE -> "Bidang"
            LayerKind.MESH -> "Model OBJ"
        }
        val layer = MotionLayer(kind = kind, name = name, text = text, image = image,
            endMs = project.durationMs, color = if (kind == LayerKind.TEXT) 0xFFF4F5F6.toInt() else 0xFFFFBD69.toInt())
        change(project.copy(layers = project.layers + layer)); selectedId = layer.id
    }

    fun toggleVisibility(id: String) = change(project.copy(layers = project.layers.map {
        if (it.id == id) it.copy(visible = !it.visible) else it
    }))

    fun toggleLock(id: String) = change(project.copy(layers = project.layers.map {
        if (it.id == id) it.copy(locked = !it.locked) else it
    }))

    fun duplicate() {
        val l = selected ?: return
        require(project.layers.size < 40) { "Maksimum 40 layer per proyek." }
        val copy = l.copy(id = UUID.randomUUID().toString(), name = l.name + " salinan", locked = false)
        change(project.copy(layers = project.layers + copy)); selectedId = copy.id
    }

    fun delete() {
        val l = selected ?: return
        if (l.locked) return
        change(project.copy(layers = project.layers.filterNot { it.id == l.id }))
        selectedId = project.layers.lastOrNull()?.id
    }

    fun reorder(up: Boolean) {
        val l = selected ?: return
        if (l.locked) return
        val layers = project.layers.toMutableList()
        val index = layers.indexOf(l)
        val target = (index + if (up) 1 else -1).coerceIn(0, layers.lastIndex)
        if (index != target) {
            layers.removeAt(index); layers.add(target, l)
            change(project.copy(layers = layers))
        }
    }

    fun toggleKeyframe() = updateLayer { l ->
        val at = if(l.kind == LayerKind.VIDEO) cursorMs else l.sourceTimeAt(cursorMs)
        if (l.keys.any { it.timeMs == at }) l.copy(pose = l.poseAt(cursorMs), keys = l.keys.filterNot { it.timeMs == at })
        else l.putKey(at, l.poseAt(cursorMs))
    }

    fun undo() {
        finishGesture()
        if (undo.isEmpty()) return
        redo.addLast(project); project = undo.removeLast(); reconcile()
    }

    fun redo() {
        finishGesture()
        if (redo.isEmpty()) return
        undo.addLast(project); project = redo.removeLast(); reconcile()
    }

    fun replace(next: MotionProject) {
        change(next); cursorMs = 0; selectedId = next.layers.lastOrNull()?.id
    }

    fun open(next: MotionProject) {
        project = next; cursorMs = 0; playing = false; selectedId = next.layers.lastOrNull()?.id
        undo.clear(); redo.clear(); continuousStart = null; refreshHistory()
    }

    private fun reconcile() {
        playing = false
        cursorMs = cursorMs.coerceAtMost(project.durationMs - 1)
        if (project.layers.none { it.id == selectedId }) selectedId = project.layers.lastOrNull()?.id
        refreshHistory()
    }

    private fun refreshHistory() { canUndo = undo.isNotEmpty(); canRedo = redo.isNotEmpty() }
}
