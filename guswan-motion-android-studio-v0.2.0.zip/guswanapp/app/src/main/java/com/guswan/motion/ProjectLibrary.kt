package com.guswan.motion

import android.util.AtomicFile
import org.json.JSONObject
import java.io.File

class ProjectLibrary(filesDir: File) {
    private val root = File(filesDir,"projects").apply { mkdirs() }
    private fun file(id: String, extension: String): File {
        require(id.matches(Regex("[A-Za-z0-9-]{1,80}")))
        return File(root,"$id.$extension")
    }
    @Synchronized fun save(project: MotionProject): String {
        val encoded = ProjectCodec.encode(project)
        require(encoded.length <= 24_000_000) { "Proyek melebihi batas 24 MB. Hapus beberapa media lalu coba simpan lagi." }
        write(file(project.id,"gwm"),encoded)
        write(file(project.id,"json"),JSONObject().put("id",project.id).put("name",project.name)
            .put("width",project.width).put("height",project.height).put("layers",project.layers.size)
            .put("durationMs",project.durationMs).put("updated",System.currentTimeMillis())
            .put("threeD",project.layers.any { it.kind.is3D }).toString())
        return encoded
    }
    private fun write(target: File, text: String) {
        val atomic = AtomicFile(target); val stream = atomic.startWrite()
        try { stream.write(text.toByteArray()); atomic.finishWrite(stream) }
        catch(t: Exception) { atomic.failWrite(stream); throw t }
    }
    @Synchronized fun list(): List<ProjectEntry> = root.listFiles().orEmpty().filter { it.extension == "json" }.map { file ->
        val o = JSONObject(AtomicFile(file).openRead().bufferedReader().use { it.readText() })
        ProjectEntry(o.getString("id"),o.getString("name"),o.getInt("width"),o.getInt("height"),
            o.getInt("durationMs"),o.getInt("layers"),o.getLong("updated"),o.getBoolean("threeD"))
    }.sortedByDescending { it.updated }
    @Synchronized fun open(id: String): MotionProject = AtomicFile(file(id,"gwm")).openRead().use { ProjectCodec.decode(it.readProjectText()) }
    @Synchronized fun delete(id: String) {
        listOf("gwm","json").forEach { AtomicFile(file(id,it)).delete() }
    }
}

data class ProjectEntry(val id: String,val name: String,val width: Int,val height: Int,
    val durationMs: Int,val layers: Int,val updated: Long,val threeD: Boolean)
