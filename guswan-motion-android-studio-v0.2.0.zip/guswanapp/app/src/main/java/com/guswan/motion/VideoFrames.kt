package com.guswan.motion

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Base64
import java.io.Closeable
import java.io.File

class VideoFrames : Closeable {
    private var encoded: String? = null
    private var retriever: MediaMetadataRetriever? = null
    private var file: File? = null
    private var bitmap: Bitmap? = null
    private var lastTime = -1

    @Synchronized fun frame(layer: MotionLayer, timeMs: Int): Bitmap? {
        val data = layer.video ?: return null
        if (encoded != data) {
            close()
            val temp = File.createTempFile("guswan-media-", ".mp4")
            try {
                temp.writeBytes(Base64.decode(data, Base64.NO_WRAP))
                val reader = MediaMetadataRetriever()
                try { reader.setDataSource(temp.absolutePath) } catch (t: Exception) { reader.release(); throw t }
                retriever = reader; file = temp; encoded = data
            } catch (t: Exception) { temp.delete(); throw t }
        }
        val at = layer.sourceTimeAt(timeMs) / 33 * 33
        if (at == lastTime && bitmap != null) return bitmap
        val reader = retriever ?: return null
        val frame = if (Build.VERSION.SDK_INT >= 27) reader.getScaledFrameAtTime(at * 1000L,
            MediaMetadataRetriever.OPTION_CLOSEST, 720, 720) else reader.getFrameAtTime(at * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
        bitmap?.recycle(); bitmap = frame; lastTime = at
        return frame
    }
    @Synchronized override fun close() {
        bitmap?.recycle(); bitmap = null
        retriever?.release(); retriever = null
        file?.delete(); file = null; encoded = null; lastTime = -1
    }
}

fun mediaSize(layer: MotionLayer, project: MotionProject): Pair<Float, Float> {
    val width = minOf(project.width * .9f, project.height * .9f * layer.mediaWidth / layer.mediaHeight)
    return width to width * layer.mediaHeight / layer.mediaWidth
}
