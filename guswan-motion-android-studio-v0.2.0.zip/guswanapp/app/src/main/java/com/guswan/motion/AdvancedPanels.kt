package com.guswan.motion

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceWindow(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest=onClose,properties=DialogProperties(usePlatformDefaultWidth=false)) {
        Scaffold(containerColor=Ink,modifier=Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            topBar={TopAppBar(title={Text(title,fontSize=20.sp)},navigationIcon={
                ToolIcon(Icons.AutoMirrored.Outlined.ArrowBack,"Tutup $title",onClick=onClose)
            },colors=TopAppBarDefaults.topAppBarColors(containerColor=Panel))}) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) { content() }
        }
    }
}

private enum class GraphProperty(val label: String, val unit: String) {
    X("Posisi X","%"),Y("Posisi Y","%"),SCALE("Skala","%"),ROTATION("Rotasi Z","°"),OPACITY("Opasitas","%"),Z("Posisi Z",""),RX("Rotasi X","°"),RY("Rotasi Y","°");
    fun read(p: Pose): Float = when(this) {
        X->p.x*100; Y->p.y*100; SCALE->p.scale*100; ROTATION->p.rotation; OPACITY->p.opacity*100; Z->p.z; RX->p.rotationX; RY->p.rotationY
    }
}
private fun decimal(v: Float) = String.format(Locale.US,"%.2f",v)

@Composable fun GraphPanel(editor: EditorState) {
    val layer = editor.selected
    if(layer == null || layer.keys.size < 2) {
        EmptyPanel("Butuh dua keyframe", "Pilih layer dan buat minimal dua keyframe dengan nilai berbeda. Graph mengatur perubahan nilai di antaranya.")
        return
    }
    var arrival by remember(layer.id) { mutableIntStateOf((layer.keys.indexOfFirst { it.timeMs >= editor.cursorMs }).coerceIn(1,layer.keys.lastIndex)) }
    arrival = arrival.coerceIn(1,layer.keys.lastIndex)
    var mode by remember { mutableIntStateOf(0) }
    var property by remember { mutableStateOf(GraphProperty.X) }
    val a = layer.keys[arrival-1]; val b = layer.keys[arrival]
    val curve = b.curve
    val currentCurve by rememberUpdatedState(curve)
    fun update(c: BezierCurve, continuous: Boolean = false) {
        editor.updateLayer(continuous) { l -> l.copy(keys=l.keys.map { if(it.timeMs==b.timeMs) it.copy(easing=Easing.BEZIER,curve=c) else it }) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(layer.name,style=MaterialTheme.typography.titleLarge)
        Text("Kurva berlaku menuju keyframe akhir segmen. Semua properti transform memakai kurva yang sama.",color=Muted,fontSize=12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            layer.keys.drop(1).forEachIndexed { index,key ->
                FilterChip(selected=arrival==index+1,onClick={editor.finishGesture();arrival=index+1
                    editor.cursorMs=(layer.keyPositions().firstOrNull { it.first.timeMs==key.timeMs }?.second ?: key.timeMs).coerceAtMost(editor.project.durationMs-1)},
                    label={Text("${timeLabel(layer.keys[index].timeMs)} / ${timeLabel(key.timeMs)}")})
            }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("Kurva","Nilai","Kecepatan").forEachIndexed { i,label ->
                TextButton(onClick={mode=i},modifier=Modifier.weight(1f)) { Text(label,color=if(mode==i) Accent else Muted) }
            }
        }
        if(mode != 0) Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            GraphProperty.entries.filter { layer.kind.is3D || it !in listOf(GraphProperty.Z,GraphProperty.RX,GraphProperty.RY) }.forEach { p ->
                FilterChip(selected=property==p,onClick={property=p},label={Text(p.label)})
            }
        }
        fun eased(t: Float) = if(b.easing==Easing.BEZIER) curve.value(t) else b.easing.fraction(t)
        fun evaluated(t: Float) = property.read(a.pose.mix(b.pose,eased(t)))
        val seconds=(b.timeMs-a.timeMs)/1000f
        val samples=(0..120).map { i ->
            val t=i/120f
            when(mode) {
                0 -> eased(t)
                1 -> evaluated(t)
                else -> {
                    val l=(t-.005f).coerceAtLeast(0f); val r=(t+.005f).coerceAtMost(1f)
                    (evaluated(r)-evaluated(l))/(r-l)/seconds
                }
            }
        }
        var min=samples.min(); var max=samples.max()
        if(mode==0) { min=-.5f;max=1.5f } else if(abs(max-min)<.01f) { min-=1;max+=1 }
        val low=min;val high=max
        Text(if(mode==0) "Progres 0–100% · ${b.easing.name.lowercase()}" else
            "${property.label} · ${decimal(low)} sampai ${decimal(high)} ${property.unit}${if(mode==2) "/s" else ""}",color=Muted,fontSize=12.sp)
        var handle by remember { mutableIntStateOf(1) }
        Canvas(Modifier.fillMaxWidth().height(240.dp).background(Panel)
            .semantics { contentDescription="Graph ${if(mode==0) "easing" else property.label}. Kontrol presisi tersedia di bawah grafik." }
            .pointerInput(mode,layer.locked,b.timeMs) {
                if(mode==0 && !layer.locked) detectDragGestures(
                    onDragStart={point ->
                        fun p(x:Float,y:Float)=Offset(20+(size.width-40)*x,20+(size.height-40)*(1.5f-y)/2)
                        handle=if((point-p(currentCurve.x1,currentCurve.y1)).getDistance() < (point-p(currentCurve.x2,currentCurve.y2)).getDistance()) 1 else 2
                    },onDragEnd=editor::finishGesture,onDragCancel=editor::finishGesture) { change,_ ->
                    change.consume()
                    val x=((change.position.x-20)/(size.width-40)).coerceIn(0f,1f)
                    val y=(1.5f-(change.position.y-20)/(size.height-40)*2).coerceIn(-1f,2f)
                    update(if(handle==1) currentCurve.copy(x1=x,y1=y) else currentCurve.copy(x2=x,y2=y),true)
                }
            }) {
            val pad=20f
            fun point(x:Float,y:Float)=Offset(pad+(size.width-2*pad)*x,pad+(size.height-2*pad)*(high-y)/(high-low))
            for(i in 0..4) {
                val x=pad+(size.width-2*pad)*i/4
                val y=pad+(size.height-2*pad)*i/4
                drawLine(Line.copy(alpha=.35f),Offset(x,pad),Offset(x,size.height-pad),1f)
                drawLine(Line.copy(alpha=.35f),Offset(pad,y),Offset(size.width-pad,y),1f)
            }
            val path=Path()
            samples.forEachIndexed { i,value -> val p=point(i/120f,value);if(i==0) path.moveTo(p.x,p.y) else path.lineTo(p.x,p.y) }
            drawPath(path,Accent,style=androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
            if(mode==0 && b.easing==Easing.BEZIER) {
                val p1=point(curve.x1,curve.y1);val p2=point(curve.x2,curve.y2)
                drawLine(Muted,point(0f,0f),p1,2f);drawLine(Muted,point(1f,1f),p2,2f)
                drawCircle(Text,7.dp.toPx(),p1);drawCircle(Accent,7.dp.toPx(),p2)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            Text(timeLabel(a.timeMs),color=Muted,fontSize=12.sp);Text(timeLabel(b.timeMs),color=Muted,fontSize=12.sp)
        }
        Text("Flow · preset easing",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=20.dp))
        FlowPreset.entries.chunked(2).forEach { presets ->
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                presets.forEach { preset ->
                    OutlinedButton(onClick={update(preset.curve)},enabled=!layer.locked,shape=RoundedCornerShape(8.dp),modifier=Modifier.weight(1f).heightIn(min=52.dp)) {
                        Text(preset.label)
                    }
                }
                if(presets.size==1) Spacer(Modifier.weight(1f))
            }
        }
        Row(Modifier.fillMaxWidth()) {
            TextButton(onClick={editor.updateLayer { l -> l.copy(keys=l.keys.map { if(it.timeMs==b.timeMs) it.copy(easing=Easing.LINEAR) else it }) }},enabled=!layer.locked) { Text("Linear") }
            TextButton(onClick={editor.updateLayer { l -> l.copy(keys=l.keys.map { if(it.timeMs==b.timeMs) it.copy(easing=Easing.HOLD) else it }) }},enabled=!layer.locked) { Text("Hold") }
        }
        Text("Handle cubic Bézier",style=MaterialTheme.typography.titleMedium)
        PropertySlider("Handle masuk X",decimal(curve.x1),curve.x1,0f..1f,!layer.locked,{update(curve.copy(x1=it),true)},editor::finishGesture)
        PropertySlider("Handle masuk Y",decimal(curve.y1),curve.y1,-1f..2f,!layer.locked,{update(curve.copy(y1=it),true)},editor::finishGesture)
        PropertySlider("Handle keluar X",decimal(curve.x2),curve.x2,0f..1f,!layer.locked,{update(curve.copy(x2=it),true)},editor::finishGesture)
        PropertySlider("Handle keluar Y",decimal(curve.y2),curve.y2,-1f..2f,!layer.locked,{update(curve.copy(y2=it),true)},editor::finishGesture)
        Text("X mengatur waktu; Y mengatur progres. Y di luar 0–1 menghasilkan overshoot.",color=Muted,fontSize=12.sp)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun TimeRemapPanel(editor: EditorState) {
    val layer=editor.selected
    if(layer==null) { EmptyPanel("Pilih layer","Time remap mengubah waktu sumber sebuah layer animasi atau video.");return }
    var index by remember(layer.id) { mutableIntStateOf(0) }
    val sourceEnd=if(layer.kind==LayerKind.VIDEO) layer.sourceDurationMs-1 else editor.project.durationMs
    val points=layer.timeRemap
    index=index.coerceIn(0,(points.size-1).coerceAtLeast(0))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(layer.name,style=MaterialTheme.typography.titleLarge)
        Text(if(layer.kind==LayerKind.VIDEO) "Waktu sumber video. Frame terdekat, tanpa audio/optical flow." else
            "Waktu sumber animasi. Keyframe transform dibaca pada waktu hasil remap.",color=Muted,fontSize=12.sp)
        Text("${timeLabel(editor.cursorMs)} komposisi = ${timeLabel(layer.sourceTimeAt(editor.cursorMs))} sumber",color=Accent,modifier=Modifier.padding(vertical=12.dp))
        RampPreset.entries.chunked(2).forEach { group -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            group.forEach { preset -> OutlinedButton(onClick={
                editor.updateLayer { it.copy(timeRemap=rampPoints(preset,layer.startMs,layer.endMs,sourceEnd)) };index=0
            },enabled=!layer.locked,shape=RoundedCornerShape(8.dp),modifier=Modifier.weight(1f).heightIn(min=52.dp)) { Text(preset.label) } }
        } }
        Text("Waktu sumber / waktu komposisi",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=16.dp))
        Canvas(Modifier.fillMaxWidth().height(200.dp).background(Panel).semantics { contentDescription="Graph time remap. Titik dapat diedit melalui slider di bawah." }) {
            val pad=20f;val w=size.width-pad*2;val h=size.height-pad*2
            for(i in 0..4) {
                drawLine(Line.copy(alpha=.35f),Offset(pad+w*i/4,pad),Offset(pad+w*i/4,pad+h),1f)
                drawLine(Line.copy(alpha=.35f),Offset(pad,pad+h*i/4),Offset(pad+w,pad+h*i/4),1f)
            }
            val path=Path()
            for(i in 0..120) {
                val t=editor.project.durationMs*i/120
                val y=pad+h*(1-layer.sourceTimeAt(t).toFloat()/sourceEnd.coerceAtLeast(1))
                val x=pad+w*i/120
                if(i==0) path.moveTo(x,y) else path.lineTo(x,y)
            }
            drawPath(path,Accent,style=androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))
            points.forEach { p -> drawCircle(Text,5.dp.toPx(),Offset(pad+w*p.timeMs/editor.project.durationMs,pad+h*(1-p.sourceMs.toFloat()/sourceEnd.coerceAtLeast(1)))) }
        }
        Row(Modifier.fillMaxWidth()) {
            TextButton(onClick={
                editor.updateLayer { l ->
                    val initial=if(l.timeRemap.isEmpty()) listOf(TimePoint(l.startMs,if(l.kind==LayerKind.VIDEO) 0 else l.startMs),TimePoint(l.endMs,sourceEnd)) else l.timeRemap
                    val next=(initial.filterNot { it.timeMs==editor.cursorMs }+TimePoint(editor.cursorMs,l.sourceTimeAt(editor.cursorMs))).sortedBy { it.timeMs }
                    index=next.indexOfFirst { it.timeMs==editor.cursorMs };l.copy(timeRemap=next)
                }
            },enabled=!layer.locked && points.size<1000,modifier=Modifier.heightIn(min=48.dp)) { Text("Titik pada playhead") }
        }
        if(points.isEmpty()) Text("Kecepatan normal. Pilih preset atau tambahkan titik untuk mulai.",color=Muted)
        else {
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                points.forEachIndexed { i,p -> FilterChip(selected=i==index,onClick={editor.finishGesture();index=i;editor.cursorMs=p.timeMs.coerceAtMost(editor.project.durationMs-1)},label={Text(timeLabel(p.timeMs))}) }
            }
            val p=points[index]
            PropertySlider("Waktu komposisi",timeLabel(p.timeMs),p.timeMs.toFloat(),0f..editor.project.durationMs.toFloat(),!layer.locked,{ value ->
                val next=value.toInt()
                if(points.none { it != p && it.timeMs==next }) editor.updateLayer(true) { l -> l.copy(timeRemap=l.timeRemap.mapIndexed { i,t -> if(i==index) t.copy(timeMs=next) else t }) }
            },editor::finishGesture)
            PropertySlider("Waktu sumber",timeLabel(p.sourceMs),p.sourceMs.toFloat(),0f..sourceEnd.toFloat(),!layer.locked,{value ->
                editor.updateLayer(true) { l -> l.copy(timeRemap=l.timeRemap.mapIndexed { i,t -> if(i==index) t.copy(sourceMs=value.toInt()) else t }) }
            },editor::finishGesture)
            Row {
                TextButton(onClick={editor.updateLayer { l -> l.copy(timeRemap=l.timeRemap.mapIndexed { i,t -> if(i==index) t.copy(curve=FlowPreset.EASE.curve) else t }) }},enabled=!layer.locked) { Text("Kurva halus") }
                TextButton(onClick={editor.updateLayer { l -> l.copy(timeRemap=l.timeRemap.mapIndexed { i,t -> if(i==index) t.copy(curve=null) else t }) }},enabled=!layer.locked) { Text("Linear") }
            }
            TextButton(onClick={editor.updateLayer { it.copy(timeRemap=it.timeRemap.filterIndexed { i,_ -> i!=index }) };index=0},enabled=!layer.locked) { Text("Hapus titik") }
        }
        Text("Garis datar = freeze. Garis menurun = reverse. Kemiringan menunjukkan kecepatan.",color=Muted,fontSize=12.sp,modifier=Modifier.padding(top=16.dp))
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun StudioPanel(editor: EditorState, renderer: CompositionRenderer, onObj: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Scene & kamera",style=MaterialTheme.typography.titleLarge)
        CompositionPreview(editor,renderer,Modifier.height(240.dp),grid=true)
        Transport(editor)
        Text("Objek",style=MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf(LayerKind.CUBE to "Kubus",LayerKind.SPHERE to "Bola",LayerKind.PLANE to "Bidang").forEach { (kind,name) ->
                OutlinedButton(onClick={editor.add(kind)},enabled=editor.project.layers.size<40,shape=RoundedCornerShape(8.dp)) { Text(name) }
            }
            OutlinedButton(onClick=onObj,enabled=editor.project.layers.size<40,shape=RoundedCornerShape(8.dp)) { Text("Impor OBJ") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            editor.project.layers.filter { it.kind.is3D }.forEach { l -> FilterChip(selected=editor.selectedId==l.id,onClick={editor.finishGesture();editor.selectedId=l.id},label={Text(l.name)}) }
        }
        val camera=editor.project.camera
        PropertySlider("Orbit kamera", "${camera.yaw.roundToInt()}°",camera.yaw,-180f..180f,true,
            {editor.change(editor.project.copy(camera=camera.copy(yaw=it)),true)},editor::finishGesture)
        PropertySlider("Elevasi kamera", "${camera.pitch.roundToInt()}°",camera.pitch,-85f..85f,true,
            {editor.change(editor.project.copy(camera=camera.copy(pitch=it)),true)},editor::finishGesture)
        PropertySlider("Jarak kamera", decimal(camera.distance),camera.distance,2f..15f,true,
            {editor.change(editor.project.copy(camera=camera.copy(distance=it)),true)},editor::finishGesture)
        PropertySlider("Lensa kamera",decimal(camera.focal),camera.focal,1f..8f,true,
            {editor.change(editor.project.copy(camera=camera.copy(focal=it)),true)},editor::finishGesture)
        OutlinedButton(onClick={editor.change(editor.project.copy(camera=Camera3D()))},shape=RoundedCornerShape(8.dp)) { Text("Reset kamera") }
        editor.selected?.takeIf { it.kind.is3D }?.let { l ->
            val pose=l.poseAt(editor.cursorMs)
            Text(l.name,style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(top=16.dp))
            Row(verticalAlignment=Alignment.CenterVertically) {
                Switch(checked=l.wireframe,onCheckedChange={value->editor.updateLayer { it.copy(wireframe=value) }},enabled=!l.locked)
                Text("Wireframe",modifier=Modifier.padding(start=8.dp))
            }
            PropertySlider("Kedalaman Z",decimal(pose.z),pose.z,-4f..4f,!l.locked,{editor.pose(pose.copy(z=it),true)},editor::finishGesture)
            PropertySlider("Rotasi objek X","${pose.rotationX.roundToInt()}°",pose.rotationX,-360f..360f,!l.locked,{editor.pose(pose.copy(rotationX=it),true)},editor::finishGesture)
            PropertySlider("Rotasi objek Y","${pose.rotationY.roundToInt()}°",pose.rotationY,-360f..360f,!l.locked,{editor.pose(pose.copy(rotationY=it),true)},editor::finishGesture)
            OutlinedButton(onClick=editor::toggleKeyframe,enabled=!l.locked,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth()) { Text("Tambah / hapus keyframe 3D") }
            Text("Posisi XY, skala, warna dan opasitas tersedia di Properti. Grid hanya panduan dan tidak diekspor.",color=Muted,fontSize=12.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable fun TrackingPanel(editor: EditorState, onTrack: (MotionLayer) -> Unit) {
    var sourceId by remember { mutableStateOf(editor.selected?.takeIf { it.kind==LayerKind.VIDEO }?.id) }
    val videos=editor.project.layers.filter { it.kind==LayerKind.VIDEO }
    val source=videos.find { it.id==sourceId }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("Face tracking · pose 3D",style=MaterialTheme.typography.titleLarge)
        Text("Analisis video di HP untuk mengikuti posisi wajah, ukuran dan sudut kepala XYZ.",color=Muted,modifier=Modifier.padding(vertical=12.dp))
        if(videos.isEmpty()) Text("Belum ada video. Tutup panel ini dan pilih Tambah > Video.",color=Accent)
        else videos.forEach { video -> FilterChip(selected=video.id==sourceId,onClick={sourceId=video.id},label={Text(video.name)}) }
        Text("Wajah terbesar di awal menjadi target. Hasil dibake setiap 200 ms (5 fps) menjadi objek wireframe dengan keyframe. Frame tanpa deteksi menyembunyikan objek.",modifier=Modifier.padding(vertical=16.dp))
        Text("Kamera scene beralih ke tampak depan untuk overlay. Jika transform atau time remap video diubah sesudahnya, jalankan tracking lagi.",color=Muted,fontSize=12.sp)
        Button(onClick={source?.let(onTrack)},enabled=source!=null && editor.project.layers.size<40,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth().padding(vertical=16.dp).heightIn(min=52.dp)) { Text("Lacak wajah dari video") }
        Text("Estimasi pose kepala; belum face mesh, kedalaman terkalibrasi, kamera langsung, atau camera tracking scene.",color=Muted,fontSize=12.sp)
    }
}

@Composable private fun EmptyPanel(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text(title,style=MaterialTheme.typography.titleLarge)
        Text(body,color=Muted,modifier=Modifier.padding(top=12.dp))
    }
}
