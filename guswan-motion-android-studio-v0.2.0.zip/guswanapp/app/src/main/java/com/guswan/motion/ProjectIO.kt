package com.guswan.motion

import java.io.ByteArrayOutputStream
import java.io.InputStream

fun InputStream.readProjectText(limit: Int = 24_000_000): String {
    val output = ByteArrayOutputStream()
    val buffer = ByteArray(16 * 1024)
    var total = 0
    while (true) {
        val count = read(buffer)
        if (count == -1) break
        total += count
        require(total <= limit) { "Maksimum ukuran proyek 24 MB." }
        output.write(buffer, 0, count)
    }
    return output.toString(Charsets.UTF_8.name())
}
