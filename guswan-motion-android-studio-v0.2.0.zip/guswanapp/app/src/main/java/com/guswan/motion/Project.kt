package com.guswan.motion

import java.util.UUID
import kotlin.math.roundToInt

enum class LayerKind { TEXT, RECTANGLE, CIRCLE, IMAGE, VIDEO, CUBE, SPHERE, PLANE, MESH }
val LayerKind.is3D: Boolean get() = this in listOf(LayerKind.CUBE, LayerKind.SPHERE, LayerKind.PLANE, LayerKind.MESH)
enum class Easing {
    LINEAR, SMOOTH, HOLD, BEZIER;
    fun fraction(t: Float): Float = when (this) {
        LINEAR, BEZIER -> t
        SMOOTH -> t * t * (3 - 2 * t)
        HOLD -> if (t >= 1) 1f else 0f
    }
}

data class Pose(
    val x: Float = .5f, val y: Float = .5f, val scale: Float = 1f,
    val rotation: Float = 0f, val opacity: Float = 1f,
    val z: Float = 0f, val rotationX: Float = 0f, val rotationY: Float = 0f,
) {
    fun mix(other: Pose, f: Float) = Pose(
        x + (other.x - x) * f, y + (other.y - y) * f,
        (scale + (other.scale - scale) * f).coerceIn(.01f, 10f), rotation + (other.rotation - rotation) * f,
        (opacity + (other.opacity - opacity) * f).coerceIn(0f, 1f), z + (other.z - z) * f,
        rotationX + (other.rotationX - rotationX) * f, rotationY + (other.rotationY - rotationY) * f,
    )
}

data class Keyframe(val timeMs: Int, val pose: Pose, val easing: Easing = Easing.SMOOTH, val curve: BezierCurve = BezierCurve())
data class Camera3D(val yaw: Float = -22f, val pitch: Float = 15f, val distance: Float = 5f, val focal: Float = 4f)

data class MotionLayer(
    val id: String = UUID.randomUUID().toString(), val kind: LayerKind = LayerKind.TEXT,
    val name: String = "Teks", val text: String = "Teks baru", val color: Int = 0xFFF4F5F6.toInt(),
    val visible: Boolean = true, val locked: Boolean = false, val startMs: Int = 0, val endMs: Int = 6000,
    val pose: Pose = Pose(), val keys: List<Keyframe> = emptyList(), val shadow: Float = 0f, val image: String? = null,
    val video: String? = null, val sourceDurationMs: Int = 6000, val mediaWidth: Int = 1080, val mediaHeight: Int = 1920,
    val timeRemap: List<TimePoint> = emptyList(), val mesh: MeshData? = null,
    val wireframe: Boolean = false, val brightness: Float = 0f, val saturation: Float = 1f,
    val blend: BlendMode = BlendMode.NORMAL,
) {
    fun sourceTimeAt(timeMs: Int): Int = if (timeRemap.isEmpty()) {
        if (kind == LayerKind.VIDEO) (timeMs - startMs).coerceIn(0, sourceDurationMs - 1) else timeMs
    } else remapTime(timeMs, timeRemap).coerceIn(0, if (kind == LayerKind.VIDEO) sourceDurationMs - 1 else 30000)

    fun poseAt(timeMs: Int): Pose = poseAtSource(if (kind == LayerKind.VIDEO) timeMs else sourceTimeAt(timeMs))
    fun keyTimeAt(timeMs: Int): Int = if(kind==LayerKind.VIDEO) timeMs else sourceTimeAt(timeMs)

    private val mappedKeyPositions by lazy { calculateKeyPositions() }
    fun keyPositions(): List<Pair<Keyframe,Int>> = mappedKeyPositions
    private fun calculateKeyPositions(): List<Pair<Keyframe,Int>> {
        if(kind==LayerKind.VIDEO || timeRemap.isEmpty()) return keys.map { it to it.timeMs }
        val points=timeRemap.sortedBy { it.timeMs }
        return keys.flatMap { key ->
            points.zipWithNext().flatMap { (a,b) ->
                if(key.timeMs !in minOf(a.sourceMs,b.sourceMs)..maxOf(a.sourceMs,b.sourceMs)) emptyList()
                else if(a.sourceMs==b.sourceMs) listOf(key to a.timeMs,key to b.timeMs)
                else {
                    val target=(key.timeMs-a.sourceMs).toFloat()/(b.sourceMs-a.sourceMs)
                    var lo=0f;var hi=1f
                    repeat(24) { val t=(lo+hi)/2;val f=b.curve?.value(t) ?: t
                        if(f<target) lo=t else hi=t }
                    listOf(key to (a.timeMs+(b.timeMs-a.timeMs)*(lo+hi)/2).roundToInt())
                }
            }
        }.distinctBy { it.second }.sortedBy { it.second }
    }
    fun poseAtSource(timeMs: Int): Pose {
        if (keys.isEmpty()) return pose
        val sorted = keys.sortedBy { it.timeMs }
        if (timeMs <= sorted.first().timeMs) return sorted.first().pose
        if (timeMs >= sorted.last().timeMs) return sorted.last().pose
        val right = sorted.indexOfFirst { it.timeMs >= timeMs }
        val a = sorted[right - 1]; val b = sorted[right]
        val f = (timeMs - a.timeMs).toFloat() / (b.timeMs - a.timeMs)
        return a.pose.mix(b.pose, if (b.easing == Easing.BEZIER) b.curve.value(f) else b.easing.fraction(f))
    }
    fun putKey(timeMs: Int, value: Pose, easing: Easing = Easing.SMOOTH, curve: BezierCurve = BezierCurve()): MotionLayer = copy(
        keys = (keys.filterNot { it.timeMs == timeMs } + Keyframe(timeMs, value, easing, curve)).sortedBy { it.timeMs })
    fun editPose(timeMs: Int, value: Pose): MotionLayer {
        val at = if (kind == LayerKind.VIDEO) timeMs else sourceTimeAt(timeMs)
        val existing = keys.firstOrNull { it.timeMs == at }
        return if (keys.isEmpty()) copy(pose = value) else putKey(at, value, existing?.easing ?: Easing.SMOOTH, existing?.curve ?: BezierCurve())
    }
}

enum class BlendMode(val label: String) { NORMAL("Normal"), ADD("Add"), MULTIPLY("Multiply"), SCREEN("Screen") }

data class MotionProject(
    val name: String = "Proyek baru", val width: Int = 1080, val height: Int = 1920,
    val durationMs: Int = 6000, val background: Int = 0xFF151D24.toInt(), val layers: List<MotionLayer> = emptyList(),
    val id: String = UUID.randomUUID().toString(), val camera: Camera3D = Camera3D(),
) {
    fun resizedDuration(duration: Int): MotionProject {
        require(duration in 1000..30000)
        return copy(durationMs = duration, layers = layers.map { layer -> layer.copy(
            startMs = layer.startMs.coerceAtMost(duration - 1), endMs = layer.endMs.coerceAtMost(duration),
            keys = layer.keys.filter { it.timeMs <= duration }, timeRemap = layer.timeRemap.filter { it.timeMs <= duration }) })
    }
    companion object {
        fun example() = MotionProject(name = "Contoh animasi", layers = listOf(
            MotionLayer(kind = LayerKind.CIRCLE, name = "Lingkaran", color = 0xFFFFBD69.toInt(),
                pose = Pose(y = .42f, scale = 1.2f), keys = listOf(
                    Keyframe(0, Pose(x = -.15f, y = .42f, scale = .4f)), Keyframe(1800, Pose(y = .42f, scale = 1.2f)),
                    Keyframe(5000, Pose(x = .7f, y = .35f, scale = .8f)))),
            MotionLayer(name = "Judul", text = "BUAT\nGERAK.", color = 0xFFF4F5F6.toInt(), keys = listOf(
                Keyframe(300, Pose(y = .65f, opacity = 0f)), Keyframe(2000, Pose(y = .57f)), Keyframe(5000, Pose(y = .52f)))),
        ))
        fun scene3D() = MotionProject(name = "Studio 3D", width = 1920, height = 1080, layers = listOf(
            MotionLayer(kind = LayerKind.CUBE, name = "Kubus", color = 0xFFFFBD69.toInt(), keys = listOf(
                Keyframe(0, Pose(rotationX = 15f, rotationY = 0f)),
                Keyframe(6000, Pose(rotationX = 15f, rotationY = 360f), Easing.LINEAR))),
        ))
    }
}
