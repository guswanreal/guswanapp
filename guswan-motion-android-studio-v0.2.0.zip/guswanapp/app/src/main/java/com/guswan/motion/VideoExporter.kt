package com.guswan.motion

import android.graphics.Canvas
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import kotlinx.coroutines.ensureActive
import java.io.File
import kotlin.coroutines.coroutineContext

object VideoExporter {
    suspend fun export(project: MotionProject, file: File, progress: (Float) -> Unit) {
        val width: Int
        val height: Int
        if (project.width == project.height) { width = 720; height = 720 }
        else if (project.width < project.height) { width = 540; height = 960 }
        else { width = 960; height = 540 }
        val fps = 30
        val frames = (project.durationMs * fps / 1000).coerceAtLeast(1)
        val format = MediaFormat.createVideoFormat("video/avc", width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, 3_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType("video/avc")
        var muxer: MediaMuxer? = null
        var started = false
        var muxStarted = false
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val renderer = CompositionRenderer()
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start(); started = true
            val sink = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = sink
            val pixels = IntArray(width * height)
            val info = MediaCodec.BufferInfo()
            var track = -1
            var inputFrame = 0
            var inputDone = false
            var outputDone = false
            var lastOutputNs = System.nanoTime()
            while (!outputDone) {
                coroutineContext.ensureActive()
                check(System.nanoTime() - lastOutputNs < 60_000_000_000L) { "Encoder tidak merespons. Coba ekspor ulang." }
                if (!inputDone) {
                    val index = codec.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        if (inputFrame == frames) {
                            codec.queueInputBuffer(index, 0, 0, inputFrame * 1_000_000L / fps,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            renderer.draw(Canvas(bitmap), project, inputFrame * 1000 / fps)
                            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                            val image = checkNotNull(codec.getInputImage(index)) {
                                "Encoder perangkat ini tidak mendukung input YUV."
                            }
                            try {
                                val planes = image.planes
                                for (y in 0 until height) {
                                    for (x in 0 until width) {
                                        val color = pixels[y * width + x]
                                        val r = color shr 16 and 255
                                        val g = color shr 8 and 255
                                        val b = color and 255
                                        val yy = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255)
                                        planes[0].buffer.put(y * planes[0].rowStride + x * planes[0].pixelStride, yy.toByte())
                                        if (y % 2 == 0 && x % 2 == 0) {
                                            val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255)
                                            val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255)
                                            planes[1].buffer.put(y / 2 * planes[1].rowStride + x / 2 * planes[1].pixelStride, u.toByte())
                                            planes[2].buffer.put(y / 2 * planes[2].rowStride + x / 2 * planes[2].pixelStride, v.toByte())
                                        }
                                    }
                                }
                            } finally { image.close() }
                            codec.queueInputBuffer(index, 0, width * height * 3 / 2,
                                inputFrame * 1_000_000L / fps, 0)
                            inputFrame++
                            if (inputFrame % 3 == 0) progress(inputFrame.toFloat() / frames)
                        }
                    }
                }
                val index = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        check(!muxStarted)
                        track = sink.addTrack(codec.outputFormat); sink.start(); muxStarted = true
                        lastOutputNs = System.nanoTime()
                    }
                    index >= 0 -> {
                        lastOutputNs = System.nanoTime()
                        val buffer = checkNotNull(codec.getOutputBuffer(index))
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            check(muxStarted)
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            sink.writeSampleData(track, buffer, info)
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(index, false)
                    }
                }
            }
            check(muxStarted) { "Encoder tidak menghasilkan video." }
        } finally {
            renderer.close()
            bitmap.recycle()
            if (started) runCatching { codec.stop() }
            codec.release()
            if (muxStarted) runCatching { muxer?.stop() }
            muxer?.release()
        }
    }
}
