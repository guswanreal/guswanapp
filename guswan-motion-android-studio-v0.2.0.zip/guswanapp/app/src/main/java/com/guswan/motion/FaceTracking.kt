package com.guswan.motion

import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.NonCancellable
import kotlin.coroutines.coroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.*

private suspend fun <T> Task<T>.resultAwait(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { if(c.isActive) c.resume(it) }
    addOnFailureListener { if(c.isActive) c.resumeWithException(it) }
    addOnCanceledListener { c.cancel() }
}

data class FaceTrackResult(val layer: MotionLayer, val detected: Int, val sampled: Int)

object FaceTracking {
    suspend fun scan(project: MotionProject, source: MotionLayer, progress: (Float) -> Unit): FaceTrackResult {
        require(source.kind == LayerKind.VIDEO && source.video != null) { "Pilih layer video untuk dilacak." }
        val detector = FaceDetection.getClient(FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE).enableTracking().build())
        val frames = VideoFrames()
        val keys = mutableListOf<Keyframe>()
        val times = (source.startMs until source.endMs step 200).toList()
        var previous: Face? = null
        var trackedId: Int? = null
        var last = Pose(opacity = 0f)
        var detected = 0
        try {
            times.forEachIndexed { index, time ->
                coroutineContext.ensureActive()
                val frame = frames.frame(source,time)
                val faces = frame?.let { withContext(NonCancellable) { detector.process(InputImage.fromBitmap(it,0)).resultAwait() } }.orEmpty()
                coroutineContext.ensureActive()
                val face = if(trackedId != null) faces.firstOrNull { it.trackingId == trackedId } else if(previous != null) {
                    faces.minByOrNull { f -> val a=f.boundingBox; val b=previous!!.boundingBox
                        (a.exactCenterX()-b.exactCenterX()).pow(2)+(a.exactCenterY()-b.exactCenterY()).pow(2) }
                } else faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
                if (face != null && frame != null) {
                    trackedId = face.trackingId; previous = face; detected++
                    val box = face.boundingBox
                    val p = source.poseAt(time); val (w,h) = mediaSize(source,project)
                    val dx = (box.exactCenterX()/frame.width-.5f)*w*p.scale
                    val dy = (box.exactCenterY()/frame.height-.5f)*h*p.scale
                    val radians = p.rotation * PI.toFloat()/180f
                    val unit = minOf(project.width,project.height)*.22f
                    last = Pose(x=(p.x+(dx*cos(radians)-dy*sin(radians))/project.width).coerceIn(-2f,3f),
                        y=(p.y+(dx*sin(radians)+dy*cos(radians))/project.height).coerceIn(-2f,3f),
                        scale=(box.width().toFloat()/frame.width*w*p.scale/(2*unit)*.65f).coerceIn(.01f,4f),
                        rotation=-face.headEulerAngleZ+p.rotation,rotationX=-face.headEulerAngleX,
                        rotationY=face.headEulerAngleY,opacity=1f)
                } else last = last.copy(opacity=0f)
                keys += Keyframe(time,last,Easing.LINEAR)
                progress((index+1).toFloat()/times.size)
            }
            require(detected > 0) { "Wajah tidak ditemukan. Gunakan video terang dengan wajah cukup besar dan terlihat dari depan." }
            return FaceTrackResult(MotionLayer(kind=LayerKind.CUBE,name="Face track 3D",color=0xFF83D4C3.toInt(),
                wireframe=true,startMs=source.startMs,endMs=source.endMs,keys=keys),detected,times.size)
        } finally { frames.close(); detector.close() }
    }
}
