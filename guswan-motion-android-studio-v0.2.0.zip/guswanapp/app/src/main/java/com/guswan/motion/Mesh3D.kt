package com.guswan.motion

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.*

data class Vec3(val x: Float, val y: Float, val z: Float) {
    operator fun minus(b: Vec3) = Vec3(x - b.x, y - b.y, z - b.z)
    fun cross(b: Vec3) = Vec3(y * b.z - z * b.y, z * b.x - x * b.z, x * b.y - y * b.x)
    fun length() = sqrt(x * x + y * y + z * z)
    fun rotate(xAngle: Float, yAngle: Float, zAngle: Float): Vec3 {
        fun radians(v: Float) = v * PI.toFloat() / 180f
        val a = radians(xAngle); val b = radians(yAngle); val c = radians(zAngle)
        val yy = y * cos(a) - z * sin(a); val zz = y * sin(a) + z * cos(a)
        val xx = x * cos(b) + zz * sin(b); val z2 = -x * sin(b) + zz * cos(b)
        return Vec3(xx * cos(c) - yy * sin(c), xx * sin(c) + yy * cos(c), z2)
    }
}

data class MeshData(val vertices: List<Vec3>, val faces: List<List<Int>>) {
    companion object {
        fun obj(text: String): MeshData {
            require(text.length <= 1_000_000) { "OBJ maksimum 1 MB." }
            val vertices = mutableListOf<Vec3>(); val faces = mutableListOf<List<Int>>()
            text.lineSequence().forEach { raw ->
                val parts = raw.substringBefore('#').trim().split(Regex("\\s+"))
                when (parts.firstOrNull()) {
                    "v" -> {
                        require(vertices.size < 2000 && parts.size >= 4) { "OBJ maksimum 2.000 vertex." }
                        val v = parts.drop(1).take(3).map { it.toFloat().also { n -> require(n.isFinite() && abs(n) < 1e6f) } }
                        vertices += Vec3(v[0], v[1], v[2])
                    }
                    "f" -> {
                        require(parts.size >= 4 && parts.size <= 65) { "Face OBJ tidak valid." }
                        val indices = parts.drop(1).map { token ->
                            val index = token.substringBefore('/').toInt()
                            (if (index < 0) vertices.size + index else index - 1).also { require(it in vertices.indices) }
                        }
                        for (i in 1 until indices.lastIndex) faces += listOf(indices[0], indices[i], indices[i + 1])
                        require(faces.size <= 4000) { "OBJ maksimum 4.000 triangle." }
                    }
                }
            }
            require(vertices.isNotEmpty() && faces.isNotEmpty()) { "OBJ harus memiliki vertex dan face." }
            val minX = vertices.minOf { it.x }; val maxX = vertices.maxOf { it.x }
            val minY = vertices.minOf { it.y }; val maxY = vertices.maxOf { it.y }
            val minZ = vertices.minOf { it.z }; val maxZ = vertices.maxOf { it.z }
            val span = maxOf(maxX - minX, maxY - minY, maxZ - minZ).coerceAtLeast(.0001f)
            return MeshData(vertices.map { Vec3((it.x - (minX + maxX) / 2) / span * 2,
                -(it.y - (minY + maxY) / 2) / span * 2, (it.z - (minZ + maxZ) / 2) / span * 2) }, faces)
        }
        val cube = MeshData(listOf(Vec3(-1f,-1f,-1f), Vec3(1f,-1f,-1f), Vec3(1f,1f,-1f), Vec3(-1f,1f,-1f),
            Vec3(-1f,-1f,1f), Vec3(1f,-1f,1f), Vec3(1f,1f,1f), Vec3(-1f,1f,1f)),
            listOf(listOf(0,3,2,1), listOf(4,5,6,7), listOf(0,1,5,4), listOf(3,7,6,2), listOf(0,4,7,3), listOf(1,2,6,5)))
        val plane = MeshData(listOf(Vec3(-1f,0f,-1f), Vec3(1f,0f,-1f), Vec3(1f,0f,1f), Vec3(-1f,0f,1f)), listOf(listOf(0,1,2,3)))
        val sphere: MeshData by lazy {
            val v = mutableListOf<Vec3>(); val f = mutableListOf<List<Int>>()
            for (lat in 0..12) for (lon in 0..20) {
                val a = PI * lat / 12; val b = 2 * PI * lon / 20
                v += Vec3((sin(a)*cos(b)).toFloat(), cos(a).toFloat(), (sin(a)*sin(b)).toFloat())
            }
            for (lat in 0 until 12) for (lon in 0 until 20) {
                val i = lat * 21 + lon
                f += listOf(i, i + 1, i + 22, i + 21)
            }
            MeshData(v, f)
        }
    }
}

object MeshRenderer {
    fun project(v: Vec3, camera: Camera3D, width: Int, height: Int): Vec3? {
        val p = v.rotate(camera.pitch, camera.yaw, 0f)
        val depth = camera.distance + p.z
        if (depth <= .15f) return null
        val factor = minOf(width, height) * .22f * camera.focal / depth
        return Vec3(width / 2f + p.x * factor, height / 2f + p.y * factor, depth)
    }
    fun draw(canvas: Canvas, project: MotionProject, layer: MotionLayer, time: Int, selected: Boolean) {
        val mesh = when (layer.kind) {
            LayerKind.CUBE -> MeshData.cube; LayerKind.SPHERE -> MeshData.sphere
            LayerKind.PLANE -> MeshData.plane; else -> layer.mesh ?: return
        }
        val pose = layer.poseAt(time)
        val unit = minOf(project.width, project.height) * .22f
        val worldX = (pose.x - .5f) * project.width / unit
        val worldY = (pose.y - .5f) * project.height / unit
        val points = mesh.vertices.map { vertex ->
            val r = Vec3(vertex.x * pose.scale, vertex.y * pose.scale, vertex.z * pose.scale)
                .rotate(pose.rotationX, pose.rotationY, pose.rotation)
            Vec3(r.x + worldX, r.y + worldY, r.z + pose.z)
        }
        val projected = points.map { project(it, project.camera, project.width, project.height) }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        mesh.faces.sortedByDescending { face -> face.map { projected[it]?.z ?: 0f }.average() }.forEach { face ->
            if (face.any { projected[it] == null }) return@forEach
            val normal = (points[face[1]] - points[face[0]]).cross(points[face[2]] - points[face[0]])
            val light = (.32f + .68f * abs((-normal.x - normal.y - normal.z) / (normal.length().coerceAtLeast(.001f) * sqrt(3f))))
            val path = Path()
            face.forEachIndexed { index, id -> val p = projected[id]!!
                if (index == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
            path.close()
            val intensity = (light + layer.brightness).coerceIn(0f, 2f)
            paint.color = Color.argb((255 * pose.opacity).toInt(),
                (Color.red(layer.color) * intensity).toInt().coerceIn(0,255),
                (Color.green(layer.color) * intensity).toInt().coerceIn(0,255),
                (Color.blue(layer.color) * intensity).toInt().coerceIn(0,255))
            paint.style = if (layer.wireframe) Paint.Style.STROKE else Paint.Style.FILL
            paint.strokeWidth = project.width * .0015f
            canvas.drawPath(path, paint)
            if (selected) {
                paint.color = 0xFFFFD399.toInt(); paint.style = Paint.Style.STROKE
                paint.strokeWidth = project.width * .0015f; canvas.drawPath(path, paint)
            }
        }
    }
    fun grid(canvas: Canvas, project: MotionProject) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF78838E.toInt(); alpha = 100; strokeWidth = 1f }
        fun line(a: Vec3, b: Vec3) {
            val p = project(a, project.camera, project.width, project.height)
            val q = project(b, project.camera, project.width, project.height)
            if (p != null && q != null) canvas.drawLine(p.x,p.y,q.x,q.y,paint)
        }
        for (i in -6..6) { line(Vec3(i.toFloat(),1.5f,-6f),Vec3(i.toFloat(),1.5f,6f))
            line(Vec3(-6f,1.5f,i.toFloat()),Vec3(6f,1.5f,i.toFloat())) }
    }
}
