package com.guswan.motion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.Base64
import android.util.LruCache
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import java.io.Closeable

class CompositionRenderer : Closeable {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val video = VideoFrames()
    private val images = object : LruCache<String, Bitmap>(20 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.allocationByteCount
    }

    fun image(encoded: String): Bitmap? = images[encoded] ?: runCatching {
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?.also { images.put(encoded, it) }
    }.getOrNull()

    @Synchronized fun draw(canvas: Canvas, project: MotionProject, timeMs: Int, selected: String? = null,
        outputWidth: Int = canvas.width, outputHeight: Int = canvas.height, grid: Boolean = false) {
        canvas.drawColor(project.background)
        canvas.save()
        canvas.scale(outputWidth.toFloat() / project.width, outputHeight.toFloat() / project.height)
        if (grid) MeshRenderer.grid(canvas, project)
        project.layers.forEach { layer ->
            if (!layer.visible || timeMs < layer.startMs || timeMs >= layer.endMs) return@forEach
            val pose = layer.poseAt(timeMs)
            if (pose.opacity <= 0f) return@forEach
            if (layer.kind.is3D) {
                MeshRenderer.draw(canvas, project, layer, timeMs, layer.id == selected)
                return@forEach
            }
            canvas.save()
            canvas.translate(pose.x * project.width, pose.y * project.height)
            canvas.rotate(pose.rotation)
            canvas.scale(pose.scale, pose.scale)
            paint.reset(); paint.isAntiAlias = true; paint.isFilterBitmap = true
            paint.color = layer.color
            paint.alpha = (pose.opacity * Color.alpha(layer.color)).toInt()
            val matrix = ColorMatrix().apply { setSaturation(layer.saturation) }
            val brightness = layer.brightness * 255f
            matrix.postConcat(ColorMatrix(floatArrayOf(1f,0f,0f,0f,brightness, 0f,1f,0f,0f,brightness,
                0f,0f,1f,0f,brightness, 0f,0f,0f,1f,0f)))
            paint.colorFilter = ColorMatrixColorFilter(matrix)
            if (layer.blend != BlendMode.NORMAL) paint.xfermode = PorterDuffXfermode(when(layer.blend) {
                BlendMode.ADD -> PorterDuff.Mode.ADD; BlendMode.MULTIPLY -> PorterDuff.Mode.MULTIPLY
                BlendMode.SCREEN -> PorterDuff.Mode.SCREEN; else -> PorterDuff.Mode.SRC_OVER
            })
            if (layer.shadow > 0) paint.setShadowLayer(layer.shadow, 0f, layer.shadow / 3, Color.BLACK)
            val unit = project.width * .30f
            var bounds = RectF(-unit / 2, -unit / 2, unit / 2, unit / 2)
            when (layer.kind) {
                LayerKind.TEXT -> {
                    paint.textSize = project.width * .105f
                    paint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
                    paint.textAlign = Paint.Align.CENTER
                    val lines = layer.text.split('\n')
                    val lineHeight = paint.textSize * 1.16f
                    val top = -(lines.size - 1) * lineHeight / 2
                    lines.forEachIndexed { index, text ->
                        canvas.drawText(text, 0f, top + index * lineHeight - (paint.ascent() + paint.descent()) / 2, paint)
                    }
                    val max = lines.maxOfOrNull { paint.measureText(it) } ?: 0f
                    bounds = RectF(-max / 2 - 16, -lines.size * lineHeight / 2, max / 2 + 16, lines.size * lineHeight / 2)
                }
                LayerKind.RECTANGLE -> canvas.drawRoundRect(bounds, unit * .06f, unit * .06f, paint)
                LayerKind.CIRCLE -> canvas.drawCircle(0f, 0f, unit / 2, paint)
                LayerKind.IMAGE -> layer.image?.let(::image)?.let { bitmap ->
                    val w = project.width * .65f
                    val h = w * bitmap.height / bitmap.width
                    bounds = RectF(-w / 2, -h / 2, w / 2, h / 2)
                    paint.alpha = (255 * pose.opacity).toInt()
                    canvas.drawBitmap(bitmap, null, bounds, paint)
                }
                LayerKind.VIDEO -> video.frame(layer, timeMs)?.let { bitmap ->
                    val (w,h) = mediaSize(layer, project)
                    bounds = RectF(-w/2,-h/2,w/2,h/2)
                    paint.alpha = (255 * pose.opacity).toInt()
                    canvas.drawBitmap(bitmap,null,bounds,paint)
                }
                else -> Unit
            }
            if (layer.id == selected) {
                paint.clearShadowLayer(); paint.colorFilter = null; paint.xfermode = null; paint.color = 0xFFFFBD69.toInt()
                paint.alpha = 255; paint.style = Paint.Style.STROKE
                val screenUnit = project.width.toFloat() / outputWidth / pose.scale
                paint.strokeWidth = 2f * screenUnit
                canvas.drawRect(bounds, paint)
                paint.style = Paint.Style.FILL
                listOf(bounds.left to bounds.top, bounds.right to bounds.top,
                    bounds.left to bounds.bottom, bounds.right to bounds.bottom).forEach { (x, y) ->
                    val handle = 4f * screenUnit
                    canvas.drawRect(x - handle, y - handle, x + handle, y + handle, paint)
                }
            }
            canvas.restore()
        }
        canvas.restore()
    }

    fun frame(project: MotionProject, timeMs: Int, width: Int = project.width, height: Int = project.height): Bitmap =
        Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
            draw(Canvas(it), project, timeMs.coerceIn(0, project.durationMs - 1))
        }

    @Synchronized override fun close() { video.close(); images.evictAll() }
}
