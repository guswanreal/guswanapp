package com.guswan.motion

import kotlin.math.abs

data class BezierCurve(val x1: Float = .42f, val y1: Float = 0f, val x2: Float = .58f, val y2: Float = 1f) {
    init {
        require(listOf(x1, y1, x2, y2).all { it.isFinite() })
        require(x1 in 0f..1f && x2 in 0f..1f && y1 in -1f..2f && y2 in -1f..2f)
    }
    private fun axis(t: Float, a: Float, b: Float): Float {
        val u = 1f - t
        return 3 * u * u * t * a + 3 * u * t * t * b + t * t * t
    }
    fun value(progress: Float): Float {
        if (progress <= 0f) return 0f
        if (progress >= 1f) return 1f
        var lo = 0f; var hi = 1f
        repeat(24) {
            val t = (lo + hi) / 2
            if (axis(t, x1, x2) < progress) lo = t else hi = t
        }
        return axis((lo + hi) / 2, y1, y2)
    }
    fun velocity(progress: Float): Float {
        val left = (progress - .001f).coerceAtLeast(0f)
        val right = (progress + .001f).coerceAtMost(1f)
        return if (abs(right - left) < 1e-7f) 0f else (value(right) - value(left)) / (right - left)
    }
}

enum class FlowPreset(val label: String, val curve: BezierCurve) {
    EASE("Easy ease", BezierCurve(.42f, 0f, .58f, 1f)),
    IN("Ease in", BezierCurve(.55f, .05f, .95f, .5f)),
    OUT("Ease out", BezierCurve(.05f, .5f, .45f, .95f)),
    SNAP("Snap", BezierCurve(.76f, 0f, .24f, 1f)),
    BACK("Overshoot", BezierCurve(.34f, 1.56f, .64f, 1f)),
}

data class TimePoint(val timeMs: Int, val sourceMs: Int, val curve: BezierCurve? = null)

fun remapTime(timeMs: Int, points: List<TimePoint>): Int {
    if (points.isEmpty()) return timeMs
    val ordered = points.sortedBy { it.timeMs }
    if (timeMs <= ordered.first().timeMs) return ordered.first().sourceMs
    if (timeMs >= ordered.last().timeMs) return ordered.last().sourceMs
    val right = ordered.indexOfFirst { it.timeMs >= timeMs }
    val a = ordered[right - 1]; val b = ordered[right]
    val t = (timeMs - a.timeMs).toFloat() / (b.timeMs - a.timeMs)
    return (a.sourceMs + (b.sourceMs - a.sourceMs) * (b.curve?.value(t) ?: t)).toInt().coerceAtLeast(0)
}

enum class RampPreset(val label: String) { NORMAL("Normal"), SPEED("Cepat–lambat"), FREEZE("Freeze"), REVERSE("Reverse") }

fun rampPoints(preset: RampPreset, start: Int, end: Int, sourceEnd: Int): List<TimePoint> {
    val span = end - start
    return when (preset) {
        RampPreset.NORMAL -> emptyList()
        RampPreset.SPEED -> listOf(TimePoint(start, 0), TimePoint(start + span / 3, sourceEnd * 2 / 3, FlowPreset.OUT.curve),
            TimePoint(start + span * 2 / 3, sourceEnd * 3 / 4, FlowPreset.EASE.curve), TimePoint(end, sourceEnd, FlowPreset.IN.curve))
        RampPreset.FREEZE -> listOf(TimePoint(start, 0), TimePoint(start + span / 3, sourceEnd / 2),
            TimePoint(start + span * 2 / 3, sourceEnd / 2), TimePoint(end, sourceEnd))
        RampPreset.REVERSE -> listOf(TimePoint(start, sourceEnd), TimePoint(end, 0))
    }
}
