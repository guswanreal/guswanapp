package com.guswan.motion

import org.junit.Assert.*
import org.junit.Test

class ProjectTest {
    @Test fun staticLayerUsesBasePose() {
        val p = Pose(x = .2f, y = .8f)
        assertEquals(p, MotionLayer(pose = p).poseAt(4500))
    }

    @Test fun interpolationHoldsBeforeAndAfterKeys() {
        val l = MotionLayer(keys = listOf(Keyframe(1000, Pose(x = 0f)), Keyframe(3000, Pose(x = 1f))))
        assertEquals(0f, l.poseAt(0).x, .001f)
        assertEquals(.5f, l.poseAt(2000).x, .001f)
        assertEquals(1f, l.poseAt(6000).x, .001f)
    }

    @Test fun arrivalKeyControlsEasing() {
        val l = MotionLayer(keys = listOf(Keyframe(0, Pose(x = 0f)),
            Keyframe(1000, Pose(x = 1f), Easing.HOLD)))
        assertEquals(0f, l.poseAt(999).x, .001f)
        assertEquals(1f, l.poseAt(1000).x, .001f)
        val linear = l.putKey(1000, Pose(x = 1f), Easing.LINEAR)
        assertEquals(.25f, linear.poseAt(250).x, .001f)
        val smooth = l.putKey(1000, Pose(x = 1f), Easing.SMOOTH)
        assertEquals(.15625f, smooth.poseAt(250).x, .001f)
    }

    @Test fun allTransformPropertiesInterpolate() {
        val p = Pose(0f, 0f, 1f, 0f, 0f).mix(Pose(1f, 1f, 3f, 180f, 1f), .5f)
        assertEquals(Pose(.5f, .5f, 2f, 90f, .5f), p)
    }

    @Test fun replacingKeyPreservesUniqueTimesAndSortOrder() {
        val layer = MotionLayer().putKey(3000, Pose()).putKey(1000, Pose(x = .2f))
            .putKey(1000, Pose(x = .7f), Easing.LINEAR)
        assertEquals(listOf(1000, 3000), layer.keys.map { it.timeMs })
        assertEquals(.7f, layer.keys.first().pose.x, .001f)
    }

    @Test fun editingAnimatedPoseCreatesKeyAtCursor() {
        val l = MotionLayer().putKey(0, Pose()).putKey(4000, Pose(x = 1f))
        val next = l.editPose(2000, l.poseAt(2000).copy(rotation = 80f))
        assertEquals(3, next.keys.size)
        assertEquals(80f, next.poseAt(2000).rotation, .001f)
        assertEquals(l.poseAt(2000).x, next.poseAt(2000).x, .001f)
    }

    @Test fun shrinkingDurationClampsLayersAndDropsOutOfRangeKeys() {
        val p = MotionProject(layers = listOf(MotionLayer(startMs = 5000, endMs = 6000)
            .putKey(0, Pose()).putKey(5000, Pose(x = 1f))))
        val next = p.resizedDuration(2000)
        assertEquals(1999, next.layers.first().startMs)
        assertEquals(2000, next.layers.first().endMs)
        assertEquals(listOf(0), next.layers.first().keys.map { it.timeMs })
        assertEquals(5000, p.layers.first().startMs)
    }

    @Test fun roundTripIncludesImagesAndAllLayerProperties() {
        val p = MotionProject.example().copy(layers = MotionProject.example().layers +
            MotionLayer(kind = LayerKind.IMAGE, image = "aGVsbG8=", shadow = 12f, visible = false, locked = true))
        assertEquals(p, ProjectCodec.decode(ProjectCodec.encode(p)))
    }

    @Test(expected = IllegalArgumentException::class)
    fun unknownFormatIsRejected() {
        ProjectCodec.decode("{\"format\":\"ae-project\",\"version\":1}")
    }

    @Test(expected = IllegalArgumentException::class)
    fun unsupportedVersionIsRejected() {
        ProjectCodec.decode(ProjectCodec.encode(MotionProject()).replace("\"version\":2", "\"version\":99"))
    }

    @Test(expected = IllegalArgumentException::class)
    fun duplicateLayerIdsAreRejected() {
        val l = MotionLayer()
        ProjectCodec.decode(ProjectCodec.encode(MotionProject(layers = listOf(l, l))))
    }

    @Test(expected = IllegalArgumentException::class)
    fun invalidTimingIsRejected() {
        ProjectCodec.decode(ProjectCodec.encode(MotionProject(layers = listOf(MotionLayer(startMs = 5500, endMs = 5000)))))
    }

    @Test(expected = IllegalArgumentException::class)
    fun excessiveCanvasIsRejected() {
        ProjectCodec.decode(ProjectCodec.encode(MotionProject(width = 100000)))
    }
}
