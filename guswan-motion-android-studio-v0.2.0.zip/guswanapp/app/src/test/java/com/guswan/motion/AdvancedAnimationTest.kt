package com.guswan.motion

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class AdvancedAnimationTest {
    @Test fun bezierSolvesTimeAxisBeforeEvaluatingValue() {
        val curve=BezierCurve(.25f,0f,.75f,1f)
        assertEquals(.15625f,curve.value(.2265625f),.00001f)
        assertEquals(0f,curve.value(0f),0f);assertEquals(1f,curve.value(1f),0f)
    }
    @Test fun flowOvershootExceedsDestinationAndVelocityReportsDerivative() {
        assertTrue(FlowPreset.BACK.curve.value(.6f)>1f)
        val identity=BezierCurve(0f,0f,1f,1f)
        assertEquals(.3f,identity.value(.3f),.0001f)
        assertEquals(1f,identity.velocity(.5f),.002f)
    }
    @Test fun bezierDrivesAllThreeDimensionsAndSurvivesRoundTrip() {
        val curve=FlowPreset.SNAP.curve
        val layer=MotionLayer(kind=LayerKind.CUBE,keys=listOf(Keyframe(0,Pose(x=0f,z=0f,rotationY=0f)),
            Keyframe(1000,Pose(x=1f,z=2f,rotationY=180f),Easing.BEZIER,curve)))
        val p=layer.poseAt(250);val t=curve.value(.25f)
        assertEquals(t,p.x,.001f);assertEquals(2*t,p.z,.001f);assertEquals(180*t,p.rotationY,.001f)
        val project=MotionProject(layers=listOf(layer),camera=Camera3D(30f,25f,8f,3f))
        assertEquals(project,ProjectCodec.decode(ProjectCodec.encode(project)))
    }
    @Test fun timeRampFreezesAndReversesAnimationSource() {
        val base=MotionLayer(keys=listOf(Keyframe(0,Pose(x=0f)),Keyframe(6000,Pose(x=1f),Easing.LINEAR)))
        val freeze=base.copy(timeRemap=rampPoints(RampPreset.FREEZE,0,6000,6000))
        assertEquals(freeze.poseAt(2200),freeze.poseAt(3800))
        val reverse=base.copy(timeRemap=rampPoints(RampPreset.REVERSE,0,6000,6000))
        assertEquals(1f,reverse.poseAt(0).x,0f);assertEquals(0f,reverse.poseAt(6000).x,0f)
        assertTrue(reverse.poseAt(1000).x>reverse.poseAt(5000).x)
    }
    @Test fun videoRemapsFramesWhileTransformUsesCompositionTime() {
        val video=MotionLayer(kind=LayerKind.VIDEO,startMs=1000,sourceDurationMs=4000,
            keys=listOf(Keyframe(0,Pose(x=0f)),Keyframe(6000,Pose(x=1f),Easing.LINEAR)),
            timeRemap=listOf(TimePoint(1000,3999),TimePoint(5000,0)))
        assertEquals(3999,video.sourceTimeAt(0));assertEquals(0,video.sourceTimeAt(6000))
        assertEquals(.5f,video.poseAt(3000).x,.001f)
    }
    @Test fun remappedPoseEditAndKeyToggleUseSourceTime() {
        val layer=MotionLayer(keys=listOf(Keyframe(0,Pose()),Keyframe(6000,Pose(x=1f))),
            timeRemap=listOf(TimePoint(0,6000),TimePoint(6000,0)))
        val editor=EditorState(MotionProject(layers=listOf(layer)))
        editor.cursorMs=1000;editor.pose(Pose(rotationY=60f))
        assertEquals(60f,editor.selected!!.keys.first { it.timeMs==5000 }.pose.rotationY,0f)
        editor.toggleKeyframe();assertFalse(editor.selected!!.keys.any { it.timeMs==5000 })
    }
    @Test fun oldProjectsMigrateWithDefaults() {
        val p=MotionProject.example()
        val o=JSONObject(ProjectCodec.encode(p)).put("version",1)
        o.remove("camera");o.remove("id")
        val migrated=ProjectCodec.decode(o.toString())
        assertEquals(p.layers,migrated.layers);assertEquals(Camera3D(),migrated.camera)
        assertTrue(migrated.id.isNotBlank())
    }
    @Test fun objTriangulatesFacesSupportsNegativeIndicesAndNormalizes() {
        val mesh=MeshData.obj("v -2 -2 0\nv 2 -2 0\nv 2 2 0\nv -2 2 0\nf -4 -3 -2 -1")
        assertEquals(2,mesh.faces.size);assertEquals(4,mesh.vertices.size)
        assertTrue(mesh.vertices.all { it.x in -1f..1f && it.y in -1f..1f })
        val p=MotionProject(layers=listOf(MotionLayer(kind=LayerKind.MESH,mesh=mesh)))
        assertEquals(p,ProjectCodec.decode(ProjectCodec.encode(p)))
    }
    @Test(expected=IllegalArgumentException::class) fun invalidObjIndicesRejected() {
        MeshData.obj("v 0 0 0\nf 1 2 3")
    }
    @Test(expected=IllegalArgumentException::class) fun duplicateRemapTimesRejected() {
        ProjectCodec.decode(ProjectCodec.encode(MotionProject(layers=listOf(MotionLayer(timeRemap=listOf(TimePoint(0,0),TimePoint(0,2)))))))
    }
    @Test(expected=IllegalArgumentException::class) fun invalidBezierRejected() { BezierCurve(Float.NaN,0f,1f,1f) }
    @Test fun openingProjectClearsHistoryAndKeepsIndependentIdentity() {
        val e=EditorState(MotionProject());e.add(LayerKind.CUBE);val old=e.project
        val next=MotionProject();e.open(next)
        assertFalse(e.canUndo);assertFalse(e.canRedo);assertNotEquals(old.id,next.id)
    }
    @Test fun reversedTimelineMarkersAndTransportUseCompositionTime() {
        val layer=MotionLayer(keys=listOf(Keyframe(1000,Pose()),Keyframe(4000,Pose())),
            timeRemap=listOf(TimePoint(0,6000),TimePoint(6000,0)))
        assertEquals(listOf(2000,5000),layer.keyPositions().map { it.second })
        assertEquals(listOf(4000,1000),layer.keyPositions().map { it.first.timeMs })
    }
    @Test fun overshootClampsPhysicalOpacityAndScaleWithoutClampingRotation() {
        val p=Pose(scale=1f,rotationY=0f,opacity=0f).mix(Pose(scale=10f,rotationY=180f,opacity=1f),1.2f)
        assertEquals(10f,p.scale,0f);assertEquals(1f,p.opacity,0f);assertEquals(216f,p.rotationY,.001f)
    }
}
