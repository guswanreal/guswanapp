package com.guswan.motion

import org.junit.Assert.*
import org.junit.Test

class EditorStateTest {
    @Test fun addDeleteUndoRedoRestoreExactProject() {
        val e = EditorState(MotionProject())
        e.add(LayerKind.TEXT, "Halo")
        val created = e.project
        assertTrue(e.canUndo)
        e.delete(); assertTrue(e.project.layers.isEmpty())
        e.undo(); assertEquals(created, e.project)
        e.redo(); assertTrue(e.project.layers.isEmpty())
    }

    @Test fun continuousGestureMakesSingleUndoEntry() {
        val e = EditorState(MotionProject.example())
        val before = e.project
        e.pose(Pose(x = .2f), true)
        e.pose(Pose(x = .3f), true)
        e.pose(Pose(x = .4f), true)
        e.finishGesture()
        e.undo(); assertEquals(before, e.project)
        assertFalse(e.canUndo)
    }

    @Test fun lockedLayerCannotBeEditedOrDeleted() {
        val l = MotionLayer(locked = true)
        val e = EditorState(MotionProject(layers = listOf(l)))
        e.pose(Pose(x = .1f)); e.delete(); e.toggleKeyframe()
        assertEquals(listOf(l), e.project.layers)
        e.toggleLock(l.id); e.delete(); assertTrue(e.project.layers.isEmpty())
    }

    @Test fun duplicateHasIndependentIdentityAndReorderChangesCompositingOrder() {
        val e = EditorState(MotionProject())
        e.add(LayerKind.CIRCLE)
        val first = e.selectedId
        e.duplicate()
        assertNotEquals(first, e.selectedId)
        val copy = e.selectedId
        e.reorder(false)
        assertEquals(copy, e.project.layers.first().id)
        assertEquals(first, e.project.layers.last().id)
    }

    @Test fun newEditInvalidatesRedo() {
        val e = EditorState(MotionProject())
        e.add(LayerKind.CIRCLE); e.undo(); assertTrue(e.canRedo)
        e.add(LayerKind.TEXT); assertFalse(e.canRedo)
    }

    @Test fun visibilityToggleDoesNotLoseKeyframes() {
        val p = MotionProject.example()
        val e = EditorState(p)
        val l = p.layers.first()
        e.toggleVisibility(l.id)
        assertFalse(e.project.layers.first().visible)
        assertEquals(l.keys, e.project.layers.first().keys)
    }

    @Test fun keyframeButtonAddsAndRemovesAtCursor() {
        val e = EditorState(MotionProject(layers = listOf(MotionLayer())))
        e.cursorMs = 2000
        e.toggleKeyframe(); assertEquals(2000, e.selected!!.keys.single().timeMs)
        e.toggleKeyframe(); assertTrue(e.selected!!.keys.isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun layerLimitIsEnforced() {
        EditorState(MotionProject(layers = List(40) { MotionLayer() })).add(LayerKind.TEXT)
    }
}
