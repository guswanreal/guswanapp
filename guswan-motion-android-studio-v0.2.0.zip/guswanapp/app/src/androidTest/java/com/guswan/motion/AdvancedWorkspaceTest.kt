package com.guswan.motion

import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import java.io.File
import androidx.test.platform.app.InstrumentationRegistry
import android.content.res.Configuration
import org.junit.Assert.assertSame

class AdvancedWorkspaceTest {
    @get:Rule val rule=createAndroidComposeRule<MainActivity>()
    private fun saved(check:(MotionProject)->Boolean) {
        rule.waitUntil(30000) { runCatching { check(ProjectCodec.decode(File(rule.activity.filesDir,"autosave.gwm").readText())) }.getOrDefault(false) }
    }
    private fun capture(name: String) {
        rule.waitForIdle()
        val bitmap=InstrumentationRegistry.getInstrumentation().uiAutomation.takeScreenshot()
        val dir=File(rule.activity.getExternalFilesDir(null),"validation").apply { mkdirs() }
        File(dir,"$name.png").outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it) }
        bitmap.recycle()
    }
    @Test fun homeStudioGraphFlowTimeRemapAndProjectRestoration() {
        capture("home")
        rule.onNodeWithText("Studio 3D baru").performClick()
        rule.onNodeWithText("Scene & kamera").assertExists()
        capture("studio-3d")
        rule.onNodeWithText("Bola",substring=false).performClick()
        rule.onNodeWithContentDescription("Orbit kamera").performScrollTo().performSemanticsAction(SemanticsActions.SetProgress) { it(40f) }
        rule.onNodeWithContentDescription("Tutup Studio 3D").performClick()
        rule.onNodeWithText("2 layer").assertExists()
        val originalActivity=rule.activity
        val automation=InstrumentationRegistry.getInstrumentation().uiAutomation
        android.os.ParcelFileDescriptor.AutoCloseInputStream(automation.executeShellCommand("wm set-user-rotation lock 1")).use { it.readBytes() }
        rule.waitUntil(30000) { rule.activity.resources.configuration.orientation==Configuration.ORIENTATION_LANDSCAPE }
        rule.waitForIdle()
        assertSame(originalActivity,rule.activity)
        capture("editor-landscape")
        android.os.ParcelFileDescriptor.AutoCloseInputStream(automation.executeShellCommand("wm set-user-rotation lock 0")).use { it.readBytes() }
        rule.waitUntil(30000) { rule.activity.resources.configuration.orientation==Configuration.ORIENTATION_PORTRAIT }
        rule.waitForIdle()
        assertSame(originalActivity,rule.activity)
        rule.onNodeWithText("Kubus",substring=false).performClick()
        rule.onNodeWithText("Alat",substring=false).performClick()
        rule.onNodeWithText("Graph & Flow",substring=false).performClick()
        rule.onNodeWithText("Snap",substring=false).performScrollTo().performClick()
        rule.onNodeWithContentDescription("Handle masuk X").performScrollTo().performSemanticsAction(SemanticsActions.SetProgress) { it(.8f) }
        rule.onNodeWithText("Kurva berlaku menuju keyframe akhir segmen.",substring=true).performScrollTo()
        capture("graph-flow")
        rule.onNodeWithText("Kecepatan",substring=false).performClick()
        rule.onNodeWithText("Rotasi Y",substring=false).performScrollTo().performClick()
        capture("graph-speed")
        rule.onNodeWithContentDescription("Tutup Graph & Flow").performClick()
        saved { p -> p.layers.first().keys.last().curve.x1==.8f && p.camera.yaw==40f }
        rule.onNodeWithText("Alat",substring=false).performClick()
        rule.onNodeWithText("Time remap",substring=false).performClick()
        rule.onNodeWithText("Reverse",substring=false).performScrollTo().performClick()
        rule.onNodeWithText("00:00.00 komposisi = 00:06.00 sumber").assertExists()
        capture("time-remap")
        rule.onNodeWithContentDescription("Tutup Time remap").performClick()
        saved { p -> p.layers.first().sourceTimeAt(0)==6000 }
        rule.onNodeWithContentDescription("Beranda",substring=false).performClick()
        rule.onNodeWithText("Ruang kerja").assertExists()
        rule.onAllNodesWithText("Studio 3D",substring=false).onFirst().performScrollTo().performClick()
        rule.onNodeWithText("2 layer").assertExists()
        rule.onNodeWithContentDescription("Beranda",substring=false).performClick()
        rule.onNodeWithContentDescription("Fitur dan panduan").performClick()
        rule.onNodeWithText("Tersedia di Guswan Motion 0.2").assertExists()
        rule.onNodeWithTag("feature-list").performScrollToNode(hasText("Fitur After Effects yang belum tersedia"))
        rule.onNodeWithText("Fitur After Effects yang belum tersedia").assertExists()
    }
}
