package com.guswan.motion

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.semantics.SemanticsActions
import androidx.test.espresso.Espresso
import org.junit.Rule
import org.junit.Test

class EditorFlowTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    @Test fun createTextAnimateDuplicateDeleteUndoAndReloadExample() {
        rule.onNodeWithText("Proyek baru").performClick()
        rule.onNodeWithText("Terapkan").performClick()
        rule.onNodeWithText("Kanvas kosong").assertExists()
        rule.onNodeWithText("Tambah").performClick()
        rule.onNodeWithText("Teks", substring = false).performClick()
        rule.onNode(hasSetTextAction()).performTextInput("Halo gerak")
        rule.onNodeWithText("Terapkan").performClick()
        rule.onNodeWithText("Tambah keyframe").performScrollTo().performClick()
        rule.onNodeWithText("Hapus keyframe ini").assertExists()
        rule.onNodeWithText("Tutup panel").performClick()
        rule.onNodeWithContentDescription("Posisi waktu komposisi")
            .performSemanticsAction(SemanticsActions.SetProgress) { it(2000f) }
        rule.onNodeWithText("Properti").performClick()
        rule.onNodeWithContentDescription("Posisi X").performScrollTo()
            .performSemanticsAction(SemanticsActions.SetProgress) { it(.7f) }
        rule.onNodeWithText("70%").assertExists()
        rule.onNodeWithText("Hapus keyframe ini").performScrollTo().assertExists()
        rule.onNodeWithText("Duplikat").performScrollTo().performClick()
        rule.onNodeWithText("Tutup panel").performClick()
        rule.onNodeWithText("2 layer").assertExists()
        rule.onNodeWithContentDescription("Urungkan").performClick()
        rule.onNodeWithText("1 layer").assertExists()
        rule.onNodeWithContentDescription("Ulangi").performClick()
        rule.onNodeWithText("2 layer").assertExists()
        rule.onNodeWithContentDescription("Posisi waktu komposisi")
            .performSemanticsAction(SemanticsActions.SetProgress) { it(2000f) }
        rule.onNodeWithText("Properti").performClick()
        rule.onNodeWithText("Hapus").performScrollTo().performClick()
        rule.onNodeWithText("Tutup panel").performClick()
        rule.onNodeWithText("1 layer").assertExists()
        rule.onNodeWithContentDescription("Menu proyek").performClick()
        rule.onNodeWithText("Muat contoh animasi").performClick()
        rule.onNodeWithText("Lanjutkan").performClick()
        rule.onNodeWithText("Contoh animasi").assertExists()
        rule.waitUntil(timeoutMillis = 20000) {
            runCatching {
                val file = java.io.File(rule.activity.filesDir, "autosave.gwm")
                ProjectCodec.decode(file.readText()).name == "Contoh animasi"
            }.getOrDefault(false)
        }
        rule.activityRule.scenario.recreate()
        rule.onNodeWithText("Contoh animasi").assertExists()
        rule.mainClock.autoAdvance = false
        rule.onNodeWithContentDescription("Putar preview").performClick()
        rule.mainClock.advanceTimeBy(100)
        rule.onNodeWithContentDescription("Jeda preview").assertExists()
        rule.onNodeWithContentDescription("Jeda preview").performClick()
        rule.mainClock.autoAdvance = true
        rule.onNodeWithText("Ekspor").performClick()
        rule.onNodeWithText("Video MP4").assertExists()
        rule.onNodeWithText("Frame PNG").assertExists()
        rule.onNodeWithText("Proyek .gwm").assertExists()
    }
}
