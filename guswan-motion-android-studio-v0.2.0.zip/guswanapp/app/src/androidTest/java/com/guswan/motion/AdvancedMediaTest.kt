package com.guswan.motion

import android.graphics.Color
import android.util.Base64
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class AdvancedMediaTest {
    private val instrumentation=InstrumentationRegistry.getInstrumentation()
    private fun video(): MotionLayer = MotionLayer(kind=LayerKind.VIDEO,name="Tracking test",endMs=1200,
        sourceDurationMs=1200,mediaWidth=480,mediaHeight=480,video=Base64.encodeToString(
            instrumentation.context.assets.open("face-motion.mp4").use { it.readBytes() },Base64.NO_WRAP))
    @Test fun actualBundledFaceModelTracksMovingVideoToThreeAxisKeyframes() = runBlocking {
        val source=video()
        val p=MotionProject(width=1080,height=1080,durationMs=1200,layers=listOf(source))
        val result=FaceTracking.scan(p,source) {}
        assertTrue("Face must be detected in most samples",result.detected>=4)
        assertEquals(6,result.sampled)
        assertTrue(result.layer.keys.last().pose.x>result.layer.keys.first().pose.x+.03f)
        assertTrue(result.layer.keys.all { it.pose.rotationX.isFinite() && it.pose.rotationY.isFinite() })
        assertEquals(result.layer,ProjectCodec.decode(ProjectCodec.encode(p.copy(layers=listOf(result.layer)))).layers.single())
    }
    @Test fun videoFramesFollowReverseAndFreezeInRenderer() {
        val source=video();val p=MotionProject(width=480,height=480,durationMs=1200,layers=listOf(source))
        CompositionRenderer().use { renderer ->
            val first=renderer.frame(p,0);val late=renderer.frame(p,1000)
            val reverse=source.copy(timeRemap=listOf(TimePoint(0,1000),TimePoint(1200,0)))
            val reversed=renderer.frame(p.copy(layers=listOf(reverse)),0)
            try {
                val a=IntArray(480*480);val b=IntArray(a.size);val c=IntArray(a.size)
                first.getPixels(a,0,480,0,0,480,480);late.getPixels(b,0,480,0,0,480,480);reversed.getPixels(c,0,480,0,0,480,480)
                assertTrue(a.indices.count { a[it]!=b[it] }>1000)
                assertArrayEquals(b,c)
            } finally { first.recycle();late.recycle();reversed.recycle() }
        }
    }
    @Test fun perspectiveMeshCameraAndAnimationChangeRenderedPixels() {
        val p=MotionProject.scene3D()
        CompositionRenderer().use { renderer ->
            val a=renderer.frame(p,0,320,180)
            val b=renderer.frame(p,1300,320,180)
            val c=renderer.frame(p.copy(camera=Camera3D(60f,40f,7f,4f)),1300,320,180)
            try {
                val pa=IntArray(320*180);val pb=IntArray(pa.size);val pc=IntArray(pa.size)
                a.getPixels(pa,0,320,0,0,320,180);b.getPixels(pb,0,320,0,0,320,180);c.getPixels(pc,0,320,0,0,320,180)
                assertTrue(pa.any { it != p.background });assertTrue(pa.indices.count { pa[it]!=pb[it] }>100)
                assertTrue(pb.indices.count { pb[it]!=pc[it] }>100)
            } finally {a.recycle();b.recycle();c.recycle()}
        }
    }
    @Test fun projectLibraryRestoresIndependentProjectsAndDeletesOnlyChosenId() {
        val dir=File(instrumentation.targetContext.cacheDir,"library-test-${System.nanoTime()}").apply { mkdirs() }
        try {
            val library=ProjectLibrary(dir);val a=MotionProject.example();val b=MotionProject.scene3D()
            library.save(a);library.save(b)
            val reopened=ProjectLibrary(dir)
            assertEquals(2,reopened.list().size);assertEquals(a,reopened.open(a.id));assertEquals(b,reopened.open(b.id))
            reopened.delete(a.id);assertEquals(listOf(b.id),reopened.list().map { it.id });assertEquals(b,reopened.open(b.id))
        } finally {dir.deleteRecursively()}
    }
}
