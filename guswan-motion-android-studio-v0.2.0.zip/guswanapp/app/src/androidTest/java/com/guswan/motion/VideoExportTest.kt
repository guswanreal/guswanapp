package com.guswan.motion

import android.graphics.Color
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class VideoExportTest {
    @Test fun encodedMp4ContainsThirtyAnimatedFramesWithExpectedDimensions() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val file = File(context.cacheDir, "encoder-test.mp4")
        val layer = MotionLayer(kind = LayerKind.RECTANGLE, color = Color.WHITE, endMs = 1000,
            keys = listOf(Keyframe(0, Pose(x = .15f)), Keyframe(1000, Pose(x = .85f), Easing.LINEAR)))
        val project = MotionProject(durationMs = 1000, layers = listOf(layer))
        try {
            VideoExporter.export(project, file) { }
            assertTrue(file.length() > 1000)
            val extractor = MediaExtractor()
            try {
                extractor.setDataSource(file.absolutePath)
                assertEquals(1, extractor.trackCount)
                val format = extractor.getTrackFormat(0)
                assertEquals("video/avc", format.getString(MediaFormat.KEY_MIME))
                assertEquals(540, format.getInteger(MediaFormat.KEY_WIDTH))
                assertEquals(960, format.getInteger(MediaFormat.KEY_HEIGHT))
                extractor.selectTrack(0)
                var frames = 0
                while (extractor.sampleTime >= 0) { frames++; extractor.advance() }
                assertEquals(30, frames)
            } finally { extractor.release() }
            val reader = MediaMetadataRetriever()
            try {
                reader.setDataSource(file.absolutePath)
                val first = checkNotNull(reader.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST))
                val last = checkNotNull(reader.getFrameAtTime(900000, MediaMetadataRetriever.OPTION_CLOSEST))
                try {
                    assertNotEquals(first.getPixel(81, 480), last.getPixel(81, 480))
                } finally { first.recycle(); last.recycle() }
            } finally { reader.release() }
        } finally { file.delete() }
    }
}
